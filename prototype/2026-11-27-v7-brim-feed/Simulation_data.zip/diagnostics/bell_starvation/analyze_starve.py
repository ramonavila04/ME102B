from pathlib import Path
import math,json
import numpy as np
base=Path(__file__).parent.parent
x,y=-15.6*math.sqrt(3)/2,-7.8
checks={}
for tag,loc in [('bell',base/'design/bell/continuation751/motor/after_6.npz'),('fixed',base/'fixed/continuation751_fine/motor/after_6.npz')]:
 s=np.load(loc);q=s['qpos'][1:].reshape(-1,7);live=s['active']; phi=np.degrees(s['qpos'][0]);w,a,b,c=q[:,3:].T;axis=np.c_[2*(a*c+w*b),2*(b*c-w*a),1-2*(a*a+b*b)];tilt=np.rad2deg(np.arccos(abs(axis[:,2]).clip(0,1)))
 rows=[]
 for k in range(6):
    az=math.radians(-150+60*k);xy=np.array([15.6*math.cos(az),15.6*math.sin(az)]);near=[]
    for i in np.flatnonzero(live):
        r=q[i,:3];u=axis[i,:2]; off=xy-r[:2];pars=np.dot(off,u)/max(np.dot(u,u),1.e-10); t=np.clip(pars,-7.,7.); d=np.linalg.norm(off-u*t); low=r[2]-3.875-7*abs(axis[i,2]);zc=r[2]+t*axis[i,2]; 
        if d<8. and low<136:near.append(dict(id=int(i),center_xyz=np.round(r,2).tolist(),towards_throat_xy_mm=round(float(d),2),min_tip=round(float(low),2),tilt=round(float(tilt[i]),1),z_at_projection=round(float(zc),2)))
    rows.append(dict(azimuth=-150+60*k,xy=xy.round(2).tolist(),nearest=sorted(near,key=lambda z:z['min_tip'])[:6]))
 checks[tag]=rows
print(json.dumps([checks['bell'][0],checks['fixed'][0]],indent=2));(base/'active/starvation_geometry.json').write_text(json.dumps(checks,indent=2))
