"""Gauge, release and build dimensions for flat-end cylindrical capsules. Millimeters."""
from math import radians, sin, cos, atan2, degrees, hypot, sqrt
import cadquery as cq

TILT=50.
TRACK=28.5
LENGTH=21.75
DIAMETER=7.75
Z0=-7.50+DIAMETER/2
FALL=18.0
PHASE=60.
def add(a,b):
    return tuple(a[i]+b[i] for i in range(3))
def mul(v,k):
    return tuple(k*x for x in v)
def unit(v):
    return mul(v,1/sqrt(sum(x*x for x in v)))
def shaft(a=PHASE):
    return (cos(radians(a)),sin(radians(a)),0.)
def localcentre(d,a=PHASE):
    return (-TRACK*sin(radians(a)),TRACK*cos(radians(a))-d*sin(radians(TILT)),Z0-d*cos(radians(TILT)))
def gravity_vector(d):
    return (0.,-sin(radians(TILT))*d,-cos(radians(TILT))*d)
def solid_pill(d=0,a=PHASE,clear=0.,axial_clear=0.):
    u=shaft(a);p=add(localcentre(d,a),mul(u,-LENGTH/2-axial_clear))
    return cq.Solid.makeCylinder(DIAMETER/2+clear,LENGTH+2*axial_clear,p,u)
def exact_sweep(clear=.55,axial_clear=.65,fall=FALL,phase=PHASE):
    """Exact convex Minkowski sum of a flat-end round cylinder and a vertical segment.
    The two oblique end prisms, central side silhouette, and start/end cylinders span
    all gravity rays through the cylinder, including its sloping flat ends.
    """
    if fall==0:return solid_pill(0,phase,clear,axial_clear)
    r=DIAMETER/2+clear
    u=shaft(phase);d=gravity_vector(fall);c=localcentre(0,phase)
    uv=cq.Vector(*u);dv=cq.Vector(*d)
    n=uv.cross(dv).normalized().toTuple()
    p=add(c,mul(u,-LENGTH/2-axial_clear));q=add(c,mul(u,LENGTH/2+axial_clear))
    X=cq.Solid.extrudeLinear
    caps=[X(cq.Wire.makeCircle(r,z,u),[],dv) for z in (p,q)]
    pts=[add(p,mul(n,r)),add(q,mul(n,r)),add(q,mul(n,-r)),add(p,mul(n,-r))]
    middle=X(cq.Wire.makePolygon(pts+pts[:1]),[],dv)
    closed=solid_pill(0,phase,clear,axial_clear).fuse(solid_pill(fall,phase,clear,axial_clear),middle,*caps).clean()
    return closed
