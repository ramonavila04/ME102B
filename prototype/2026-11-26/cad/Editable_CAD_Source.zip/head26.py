"""Cylindrical test piece retrofit. All feeding geometry in mm and in local disc coordinates."""
from functools import lru_cache
from math import cos,sin,radians,sqrt,atan2,degrees
import cadquery as cq
from gravity_release import exact_sweep,localcentre,PHASE
from OCP.BRepOffsetAPI import BRepOffsetAPI_ThruSections

ANGLE=50.0
RADIUS=38.0
PILL_L,PILL_D=21.75,7.75
TRACK=28.5
MOUTH_L,MOUTH_W,END_R=23.8,9.3,1.0
THROAT_L,THROAT_W=25.0,10.5
ROTOR_FRONT=-3.30
ROTOR_REAR=-7.05
STATOR_TOP=-7.50
STATOR_BOTTOM=-11.0
HOPPER_BORE=38.65
PADS=[(-16.,-30.),(16.,-10.),(0.,16.)]
SHELL_LUGS=[(-44.5,-8.),(44.5,-8.),(0.,-43.)]
C=cq.Solid
XO=(1,0,0); YO=(0,1,0); ZO=(0,0,1); O=(0,0,0)

def tilt(s):return s.rotate(O,XO,50).rotate(O,ZO,180).translate((0,0,95))
def flat(s):return s.translate((0,0,-95)).rotate(O,ZO,-180).rotate(O,XO,-50)
def trans(x,y,z):
    a=radians(50)
    return (-x,-y*cos(a)+z*sin(a),95+y*sin(a)+z*cos(a))
def cylinder(r,z0,z1,x=0,y=0):return C.makeCylinder(r,z1-z0,(x,y,z0))
def box(x0,x1,y0,y1,z0,z1):return C.makeBox(x1-x0,y1-y0,z1-z0,(x0,y0,z0))
def plate(w):return cq.Face.makeFromWires(w)
def rect_wire(length,width,r,x=0,y=0,z=0):
    f=plate(cq.Workplane("XY",origin=(x,y,z)).rect(length,width).val())
    return f.fillet2D(r,f.Vertices()).outerWire()
def prism(w,h):return C.extrudeLinear(w,[],cq.Vector(0,0,h))
def hexwire(af,x=0,y=0,z=0):
    pts=[(x+af/sqrt(3)*cos(radians(30+60*i)),y+af/sqrt(3)*sin(radians(30+60*i)),z) for i in range(6)]
    return cq.Wire.makePolygon(pts+[pts[0]])
def cap_screw(x,y,surface,length=10,up=False):
    """SHCS with tip toward -Z, surface = bearing face under head."""
    r=cylinder(1.49,-length,0).fuse(cylinder(2.75,0,3)).cut(prism(hexwire(2.52,z=1.5),1.6)).clean()
    if up:r=r.rotate(O,XO,180)
    return r.translate((x,y,surface))
def insert(x,y,top):
    return cylinder(2.50,top-6,top,x,y).cut(cylinder(1.51,top-6.1,top+.1,x,y))
def pilot(x,y,top):
    return cylinder(2.3,top-7.3,top+.05,x,y).fuse(C.makeCone(2.3,2.67,.40,(x,y,top-.40)))
def rotr(shape,a):return shape.rotate(O,ZO,a)

def rotor():
    disk=cylinder(RADIUS,ROTOR_REAR,ROTOR_FRONT)
    pocket=C.makeLoft([rect_wire(THROAT_L,THROAT_W,1.0,0,TRACK,ROTOR_REAR-.02),
                       rect_wire(MOUTH_L,MOUTH_W,END_R,0,TRACK,ROTOR_FRONT+.02)],True)
    access=box(-11,11,-30,-.15,ROTOR_FRONT-.05,6)
    guide=cylinder(22.55,ROTOR_FRONT-.03,.8).fuse(C.makeCone(22.55,21.50,1.50,(0,0,.80))).cut(access)
    main=box(-9.8,9.8,.18,9.,ROTOR_FRONT-.06,4.5)
    jaw=box(-9.8,9.8,-6.0,-.18,ROTOR_FRONT+.12,4.5)
    # Two clamping bolts close the gap against a round shaft. Nuts insert axially.
    shaft=cylinder(3.225,ROTOR_REAR-.1,6)
    pocket=pocket.fuse(rotr(exact_sweep(clear=.55,axial_clear=.85),-PHASE))
    disk=disk.fuse(guide,main).cut(shaft,*[rotr(pocket,60*i) for i in range(6)])
    jaw=jaw.cut(shaft)
    hw=[]
    for i,x in enumerate((-6.7,6.7),1):
        z=.60
        hole=C.makeCylinder(1.65,24,(x,-12,z),YO)
        nutbox=box(x-2.82,x+2.82,2.3,5.05,z-3.25,6)
        disk=disk.cut(hole,nutbox)
        jaw=jaw.cut(hole)
        # Nuts stand perpendicular to bolt, with antirotation flats against x walls.
        nut=prism(hexwire(5.5),2.4).cut(cylinder(1.51,-.1,2.5)).rotate(O,XO,-90).translate((x,2.45,z))
        screw=cap_screw(0,0,0,12).rotate(O,XO,90).translate((x,-6.0,z))
        hw.extend([(f'Rotor_clamp_M3x12_{i}',screw,'new'),(f'Rotor_clamp_M3_nut_{i}',nut,'new')])
    return [('Six_pocket_disc',disk.clean(),'print'),('Split_hub_jaw',jaw.clean(),'print')]+hw

# Upright bulk magazine and shade. Positive local y is the uphill discharge side.
JAR_Y = -4.
JAR_BORE = 39.6
JAR_RADIUS = 42.0
SHOULDER_Z = 157.0
RIM_Z = 247.0
LID_SPIGOT = 6.4
SHADE_SLOPE = 1.1106125             # tan(48 degrees)
SHADE_Y_END = 8.0
SHADE_END_TOP = 111.5
SHADE_T = 2.4                      # measured perpendicular to feed surface
LOWERING_ANGLE = [(ZO, -180), (XO, -50)]

def ear_pad(x,y,bottom,top,r=5.0,root=36.0):
    length=sqrt(x*x+y*y)
    xb,yb=x*root/length,y*root/length
    theta=degrees(atan2(y,x))
    w=cq.Workplane('XY',origin=(.5*(xb+x),.5*(yb+y),bottom)).slot2D(length-root+2*r,2*r,theta).val()
    return prism(w,top-bottom)

def stator():
    s=cylinder(HOPPER_BORE+2.6,STATOR_BOTTOM,STATOR_TOP)
    hw=[]
    for i,(x,y) in enumerate(SHELL_LUGS,1):
        body=ear_pad(x,y,STATOR_BOTTOM,STATOR_TOP,5.1).fuse(cylinder(5.1,-15.7,STATOR_TOP,x,y))
        s=s.fuse(body).cut(pilot(x,y,STATOR_TOP))
        hw.append((f'Hopper_M3x6_insert_{i}',insert(x,y,STATOR_TOP),'new'))
    # A world-vertical port admits the projected capsule and ±2° index variation.
    # It is drilled/printed in this new direction to preserve a constant cross section.
    xx,yy,_=trans(*localcentre(0))
    vx,vy=-cos(radians(PHASE)),-cos(radians(50))*sin(radians(PHASE))
    proj=sqrt(vx*vx+vy*vy)*PILL_L
    slot=cq.Workplane('XY',origin=(xx,yy,38)).slot2D(proj+11.2,11.2,degrees(atan2(vy,vx))).val()
    s=s.cut(cylinder(6,-12,-7),flat(prism(slot,125)))
    # Each localized pad thickens the plate at the counterbore, rather than leaving
    # a thin membrane below a socket head. Its Ø9 boss locates in a Ø9.6 saddle pocket.
    for i,(x,y) in enumerate(PADS,1):
        bearing=STATOR_TOP-3.25
        s=s.fuse(cylinder(4.50,-14.0,STATOR_BOTTOM+.15,x,y))
        s=s.cut(cylinder(1.70,-14.1,STATOR_TOP+.1,x,y),cylinder(3.15,bearing,STATOR_TOP+.1,x,y))
        hw.append((f'Stator_M3x8_{i}',cap_screw(x,y,bearing,8),'new'))
    return [('Ported_stationary_plate',s.clean(),'print')]+hw

def ring(r,z,inclined):
    # Four matching true circular arcs prevent twisting of the inclined and upright sections.
    pts=[]
    for k in range(9):
        a=radians(45*k); x,y=r*cos(a),r*sin(a)
        pts.append(trans(x,y,z) if inclined else (-x,JAR_Y-y,z))
    return cq.Wire.assembleEdges([cq.Edge.makeThreePointArc(cq.Vector(*pts[i]),cq.Vector(*pts[i+1]),cq.Vector(*pts[i+2])) for i in range(0,8,2)])
def ruled(r1,r2,low,high,top=None):
    loft=BRepOffsetAPI_ThruSections(True,True,1e-6);loft.CheckCompatibility(False)
    wires=[ring(r1,low,True),ring(r1,5.0,True),ring(r2,high,False)]
    if top is not None:wires.append(ring(r2,top,False))
    for w in wires:loft.AddWire(w.wrapped)
    loft.Build()
    s=cq.Shape.cast(loft.Shape())
    if s.Volume()<0:s=cq.Shape.cast(s.wrapped.Reversed())
    return s
def shelf():
    # Flat stock clipped to the liner for a perimeter-supported 48° ramp.
    # A round nose softens the exposed edge. It has no fasteners in the capsule stream.
    ep=SHADE_Y_END;endz=SHADE_END_TOP
    drop=SHADE_T*sqrt(1+SHADE_SLOPE**2)
    pts=[(-55,endz+SHADE_SLOPE*(ep+55)),(ep,endz),(ep,endz-drop),(-55,endz+SHADE_SLOPE*(ep+55)-drop)]
    p=cq.Workplane('YZ',origin=(-45,0,0)).polyline(pts).close().extrude(90).val()
    nose=C.makeCylinder(.5*drop,90,(-45,ep,endz-.5*drop),XO)
    return p.fuse(nose)
@lru_cache(maxsize=1)
def build_magazine():
    # Model the entire pill cavity and cut it once, leaving a closed chamber everywhere
    # except the disc seat/low feed window and the refill mouth. The straight cylindrical
    # skirt starts above the loaded disc and hides the lower side of the blend.
    low=STATOR_TOP
    outer=ruled(HOPPER_BORE+2.6,JAR_RADIUS-1.0,low,SHOULDER_Z+.2)
    inside=ruled(HOPPER_BORE,JAR_BORE,low-.10,SHOULDER_Z,RIM_Z+1)
    # The skirt originates above the rotor and stationary plate. The cap of the
    # bottom loft lies strictly inside the skirt, without a coincident shoulder.
    sleeve=cylinder(JAR_RADIUS,123.,RIM_Z,0,JAR_Y)
    outside=outer.fuse(sleeve)
    # Finger notch in the outboard rim. The 6.4 mm spigot overlaps its 5.0 mm dip.
    # The 29 mm opening lets a fingertip hook under the cap while it is seated.
    thumb=cq.Workplane('XZ',origin=(0,JAR_Y+JAR_RADIUS+1.0,RIM_Z+.40)).ellipse(15.0,5.4).extrude(7.0).val()
    # Upper outside edge has a lead and shelf below the cap for fingertip purchase.
    body=outside.cut(inside,thumb)
    body=body.fuse(shelf().intersect(outside))
    # Tabs use the open/facing side of the sloping flange for all three tool paths.
    hw=[]
    for i,(x,y) in enumerate(SHELL_LUGS,1):
        top=STATOR_TOP+3.8
        lug=ear_pad(x,y,STATOR_TOP,top,5.1,root=36)
        lug=lug.cut(cylinder(HOPPER_BORE,STATOR_TOP-.1,top+.1))
        body=body.fuse(tilt(lug)).cut(tilt(cylinder(1.7,STATOR_TOP-.1,top+.15,x,y)))
        if i==3:
            # Recess the low-side shell above the tab to admit the full SHCS cap during
            # installation. Preserve the bearing surface and a continuous chamber wall.
            body=body.cut(tilt(cylinder(3.10,top,180.,x,y)))
        hw.append((f'Hopper_M3x10_{i}',tilt(cap_screw(x,y,top,10)),'new'))
    # Open top edge of the jar at full bore. Printed inverted; no internal support.
    body=body.cut(C.makeCone(JAR_BORE,JAR_BORE+.4,.40,(0,JAR_Y,RIM_Z-.40)))
    return body.clean(),hw,inside
def lid():
    # Crown prints flat-face-down; the spigot is vented and has a round insertion lead.
    # Safe radial location is by a clearance fit. No snap beads, clips or captive hardware.
    lower=RIM_Z-LID_SPIGOT
    od=JAR_BORE-.22
    spigot=C.makeCone(od-.65,od,.65,(0,JAR_Y,lower)).fuse(cylinder(od,lower+.65,RIM_Z+.12,0,JAR_Y)).cut(cylinder(od-1.90,lower-.1,RIM_Z+.15,0,JAR_Y))
    for a in (30,150,270):
        w=box(od-3,od+2,-1.0,1.0,lower-.1,RIM_Z-1.4)
        well=C.makeCylinder(1.,4.,(od-2,0,RIM_Z-1.4),XO)
        cut=w.fuse(well).rotate(O,ZO,a).translate((0,JAR_Y,0))
        spigot=spigot.cut(cut)
    profile=[(0,RIM_Z),(42.1,RIM_Z),(42.65,RIM_Z+.55),(42.65,RIM_Z+3.2),(42.05,RIM_Z+3.8),(0,RIM_Z+3.8)]
    crown=cq.Workplane('XZ').polyline(profile).close().revolve(360,(0,0),(0,1)).val().translate((0,JAR_Y,0))
    return crown.fuse(spigot).clean()
@lru_cache(maxsize=1)
def parts():
    local=rotor()+stator()
    mag,hw,_=build_magazine()
    return [(n,tilt(s),k) for n,s,k in local]+[('Upright_magazine',mag,'print'),('Thumb_lift_lid',lid(),'print')]+hw
PRINT_ROTATIONS={
 'Six_pocket_disc':LOWERING_ANGLE,
 'Split_hub_jaw':LOWERING_ANGLE,
 'Ported_stationary_plate':LOWERING_ANGLE+[(XO,180)],
 'Upright_magazine':[(XO,180)],
 'Thumb_lift_lid':[(XO,180)],
}
