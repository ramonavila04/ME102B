"""Attach contact IDs and rotor-contact moments to exact prescribed-motion peaks."""
import numpy as np
import mujoco as mj

def label(m,c,j):
    g,f=int(c.geom[j]),int(c.flex[j])
    return m.geom(g).name if g>=0 else mj.mj_id2name(m,mj.mjtObj.mjOBJ_FLEX,f) if f>=0 else "?"
def details(m,c):
    return dict(pair=[label(m,c,0),label(m,c,1)],xyz_mm=c.pos.round(3).tolist(),overlap_mm=round(float(-c.dist),5))
def torque_sources(m,d):
    flex_id=mj.mj_name2id(m,mj.mjtObj.mjOBJ_FLEX,"rotor")
    contacts=[];torque_sum=0.;force=np.zeros(6)
    for ci in np.flatnonzero((d.contact.flex[:,0]==flex_id)|(d.contact.flex[:,1]==flex_id)):
        c=d.contact[int(ci)];mj.mj_contactForce(m,d,int(ci),force)
        f=np.array(c.frame).reshape(3,3).T@force[:3]
        # Contact force is the force on contact side 1. Positive torque increases the z hinge angle.
        sign=1 if int(c.flex[1])==flex_id else -1
        moment=sign*float(c.pos[0]*f[1]-c.pos[1]*f[0])*1e-9
        torque_sum+=moment;contacts.append(dict(torque_Nm=round(moment,5),**details(m,c)))
    return dict(sum_Nm=round(torque_sum,5),dominant=sorted(contacts,key=lambda r:abs(r['torque_Nm']),reverse=True)[:4])
