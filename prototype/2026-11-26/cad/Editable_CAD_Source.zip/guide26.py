"""Removable FDM delivery chute, in cartridge coordinates. Deck seating plane is Z=0."""
from functools import lru_cache
from math import sqrt
import cadquery as cq

OUTLET_X = 24.681724
INLET_Y = -11.93735
OUTLET_Y = -47.0
WALL = 2.0
guide_name = 'One_piece_delivery_chute'
PRINT_ROTATIONS = {guide_name: []}

def rounded_rect(width, depth, radius, x, y, z):
    face = cq.Face.makeFromWires(cq.Workplane('XY', origin=(x,y,z)).rect(width,depth).val())
    return face.fillet2D(radius, face.Vertices()).outerWire()

def path(z):
    t = min(1., max(0., (z - 10.) / 67.))
    t = t*t*(3.-2.*t)
    return OUTLET_X, OUTLET_Y + (INLET_Y-OUTLET_Y)*t

def shell_section(z, extra):
    x,y = path(z)
    # A larger lower passage accepts a cylinder that tumbles during the 100 mm descent.
    t = min(1., max(0., (z-50.) / 26.))
    inside_x = 26.4-1.8*t
    a = min(1., max(0., (z-10.)/67.))
    slope = (INLET_Y-OUTLET_Y)*6*a*(1-a)/67.
    # Keep the passage wide across the incline as the centerline changes direction.
    inside_y = 26.4*sqrt(1.+slope*slope)
    return rounded_rect(inside_x+2*extra,inside_y+2*extra,3.3+extra,x,y,z)

def blank(extra):
    zs=[-4.0,9.98,*range(10,79,2),80.,125.]
    if not extra: zs[0]-=0.1; zs[-1]+=.1
    return cq.Solid.makeLoft([shell_section(z,extra) for z in zs],True)

def tilt(s):
    return s.rotate((0,0,0),(1,0,0),50).rotate((0,0,0),(0,0,1),180).translate((0,0,95.))

def side_slot(x,y,z,length,width,thickness):
    return cq.Workplane('YZ',origin=(x,y,z)).slot2D(length,width,90).extrude(thickness).val()

def mounting_ear():
    pad = side_slot(22.,-5.,46.,18.8,12.8,4.)
    # Tapered rib supports the keyed mounting ear when printing on the open outlet.
    profile = [(-34.4,11.5),(-30.6,11.5),(-0.4,42.1),(-0.4,50.2),
               (-5.0,55.4),(-23.3,61.5),(-29.5,44.0),(-34.4,29.0)]
    rib=cq.Workplane('YZ',origin=(22,0,0)).polyline(profile).close().extrude(4.).val()
    return pad.fuse(rib)

def cap_screw():
    # M3 x 12 ISO socket-head cap screw; unthreaded display and clearance envelope.
    shank=cq.Solid.makeCylinder(1.49,12,(14,-5,46),(1,0,0))
    head=cq.Solid.makeCylinder(2.75,3,(26,-5,46),(1,0,0))
    key=cq.Workplane('YZ',origin=(27.5,-5,46)).polygon(6,2.91).extrude(1.6).val()
    return shank.fuse(head).cut(key).clean()

@lru_cache(maxsize=1)
def parts():
    whole=blank(WALL).fuse(mounting_ear())
    inside=blank(0.)
    mask=tilt(cq.Solid.makeBox(400,400,190,(-200,-200,-202.05)))
    chute=whole.cut(inside).intersect(mask)
    socket=side_slot(21.95,-5,46,14.5,8.5,1.55)
    screw_hole=cq.Solid.makeCylinder(1.72,6,(21,-5,46),(1,0,0))
    chute=chute.cut(socket,screw_hole).clean()
    assert len(chute.Solids())==1 and chute.isValid(), 'Guide must be a single closed printable solid.'
    return [(guide_name,chute,'print'),('Guide_mount_M3x12',cap_screw(),'new')]
