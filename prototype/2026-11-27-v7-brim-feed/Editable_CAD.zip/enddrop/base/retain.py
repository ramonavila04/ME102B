"""Exterior radial foot pins keep the load-relief canopy captive under either sign of load."""
from pathlib import Path
import json,os,math
from canopy import *
from canopy import canopy as roof_before,holder as holder_before
PIN_Z=146.15
PIN_ANGLES=(17.,197.)
OUTSIDE_STOP=33.37
def axial_cyl(r,xstart,xend):
    return S.makeCylinder(r,xend-xstart,(xstart,0,PIN_Z),(1,0,0))
def hexwire(af,x=0):
    rr=af/math.sqrt(3)
    return poly([(x,rr*math.cos(math.radians(30+k*60)),PIN_Z+rr*math.sin(math.radians(30+k*60))) for k in range(6)])
def hexbody(af,xstart,xend):
    return S.extrudeLinear(hexwire(af,xstart),[],(xend-xstart,0,0))
@lru_cache(None)
def roof_pin():
    c=roof_before()
    for a in PIN_ANGLES:
        c=c.cut(rot(axial_cyl(1.66,27.03,30.3),a))
    return c.clean()
def boss():
    wall_boss_profile=poly([(30.7,-4.,PIN_Z-6.4),(31.35,-4.,PIN_Z-6.4),
        (33.43,-4.,PIN_Z-4.25),(33.43,-4.,PIN_Z+3.90),(30.7,-4.,PIN_Z+3.90)])
    return S.extrudeLinear(wall_boss_profile,[],(0,8.,0))
def nut_slot():
    # 0.16 mm radial clearance, 0.16 per flat. The nut enters vertically from outside.
    t=hexbody(5.82,30.33,32.98)
    return t.fuse(box(30.33,32.98,-2.91,2.91,PIN_Z,PIN_Z+11.5))
@lru_cache(None)
def pinned_holder():
    s=holder_before()
    for a in PIN_ANGLES:
        s=s.fuse(rot(boss(),a)).cut(rot(nut_slot(),a),rot(axial_cyl(1.68,29.2,34.0),a))
    return s.clean()
@lru_cache(None)
def metal_parts():
    # M3 x 6 DIN 913 flat-point set screw, modeled crest envelope and 1.5 mm hex socket.
    stem=axial_cyl(1.5,27.57,33.17).fuse(S.makeCone(1.28,1.5,.2,(27.37,0,PIN_Z),(1,0,0)),
        S.makeCone(1.5,1.30,.20,(33.17,0,PIN_Z),(1,0,0)))
    hollow=hexbody(1.5,31.92,33.6)
    pin=stem.cut(hollow).clean()
    nut=hexbody(5.50,30.45,32.85).cut(axial_cyl(1.505,30.20,33)).clean()
    return [(f'Canopy_{name}_{i+1}',rot(s,a))for i,a in enumerate(PIN_ANGLES)for name,s in [('M3x6_flat_point_set_screw',pin),('M3_hex_nut',nut)]]
def contact(folder):
    folder.mkdir(exist_ok=True,parents=True)
    required={'roof_pin':roof_pin(),'holder_pin':pinned_holder(),'pins_and_nuts':cq.Compound.makeCompound([s for n,s in metal_parts()])}
    for n,s in required.items():
        assert s.isValid(),n
        s.exportStl(str(folder/(n+'.stl')),tolerance=.10,angularTolerance=.22)
        s.exportBrep(str(folder/(n+'.brep')))
    d=json.loads((DIR/'canopy.json').read_text());d['parts']['magazine']=[str(folder/'holder_pin.stl'),'world'];d['parts']['canopy']=[str(folder/'roof_pin.stl'),'world'];d['parts']['hardware']=[str(folder/'pins_and_nuts.stl'),'world']
    (folder/'retained.json').write_text(json.dumps(d,indent=2))
if __name__=='__main__':contact(DIR/'retained_contact')
