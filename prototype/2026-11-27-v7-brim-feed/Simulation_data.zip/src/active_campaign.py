"""True loose bulk fill followed by a single uninterrupted, bounded 60-degree indexing campaign."""
import argparse
import json
from pathlib import Path
import numpy as np
from study import run as pour
from brim import topoff
from campaign_bounded import history, read, write, sha


def main():
    parser = argparse.ArgumentParser()
    for parameter in ('spec', 'inertia', 'out'):
        parser.add_argument(parameter, type=Path)
    parser.add_argument('--seed', default=751, type=int)
    parser.add_argument('--mu', default=.45, type=float)
    parser.add_argument('--crown', required=True, type=float)
    parser.add_argument('--max-steps', default=18, type=int)
    parser.add_argument('--min-clean', default=13, type=int)
    parser.add_argument('--attempts', default=65, type=int)
    parser.add_argument('--reject-limit', default=25, type=int)
    parser.add_argument('--from-fill', type=Path)
    args = parser.parse_args()
    spec, inertia = args.spec.resolve(), args.inertia.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out/'motor/results.json').exists():
        raise RuntimeError('Choose a fresh destination for this campaign.')
    fill = args.from_fill or out/'fill'
    if not args.from_fill:
        source = out/'topoff_source'
        # Preserve cumulative gravity packing as the pile approaches the lid. Only the final deep top-off decides brim acceptance.
        pour(spec, source, seed=args.seed, mu=args.mu, dt=.001, cycles=0, allow_preliminary=True)
        topoff(spec, source, fill, dt=.001, max_attempts=args.attempts, reject_limit=args.reject_limit)
    packing=read(fill/'fill.json')
    good = (0 <= packing['lid_freeboard_mm'] <= 1.5 and packing['occupied_sectors'] == 8 and
            packing['median_sector_freeboard_mm'] <= 12 and packing['shut_lid_max_interference_mm'] <= .08 and
            packing['early_drops'] == 0 and packing['loaded'] == packing['retained_at_start'])
    if not good:
        write(out/'unsuitable_packing.json', packing)
        raise RuntimeError('Stopped before any motor command. The settled pack did not meet the prospective brim, closure, and startup criteria.')
    n = packing['loaded']
    with np.load(fill/'initial_pose.npz') as cold:
        poses = cold['qpos'][1:1+7*n].reshape(n,7)
        assert np.all(cold['active'][:n])
    axis_z=np.abs(1 - 2*(poses[:,4]**2 + poses[:,5]**2))
    tip=poses[:,2] - 7*axis_z - 3.875
    bulk=set(np.flatnonzero(tip>args.crown).tolist())
    shaft_I=read(inertia)['total_kg_m2']
    slope=.015 + .002/.08 + .0005
    dt=.0005
    while abs(1-dt*slope/shaft_I)>=1.0: dt*=.5
    angle=np.degrees(np.arccos(np.clip(axis_z,0,1)))
    info=dict(original_full_state=sha(fill/'initial_pose.npz'),source='Independent gravity pour; no insertion into cups',
              seed=packing['seed'],capsules=n,friction=packing['friction'],highest_entrance_surface_mm=args.crown,
              strict_bulk_ids=sorted(bulk),shaft_inertia_kg_m2=shaft_I,
              maximum_drive_torque_Nm=.10,dt_seconds=dt,
              local_hold_velocity_multiplier=1-dt*slope/shaft_I,
              donor_rule='Original capsule low tip is strictly above the measured highest functional inlet surface at time zero.',
              stop_rule=f'Stop on first count other than one, off-path escape, stall or unsettled angle; otherwise require a strict original-bulk outlet and {args.min_clean} consecutive clean indexes. Absolute maximum {args.max_steps} indexes.',
              commits='Motor controller, integrator, capsule poses, angular velocity and contact states continue without restart throughout.',
              brim_tip_freeboard_mm=packing['lid_freeboard_mm'],brim_8sector_median_mm=packing['median_sector_freeboard_mm'],
              shut_lid_interference_mm=packing['shut_lid_max_interference_mm'])
    write(out/'protocol.json',info)
    print('START CONTINUOUS',info,flush=True)
    history_rows=[]
    strict_exits=[]
    def observe(s):
        events=[]
        for e in s['events']:
            i=e['id']
            if i in bulk and e['valid_outlet']:strict_exits.append(i)
            events.append(dict(capsule=i,original_bulk=i in bulk,initial_center_z_mm=float(poses[i,2]),
                               initial_low_tip_mm=float(tip[i]),initial_tilt_deg=float(angle[i]),
                               outlet=e['valid_outlet'],at_angle_deg=e['index_degrees']))
        reason=''
        if not s['completed']:reason='stall' if s['stall'] else 'motion failed to settle'
        elif s['offpath']:reason='off-path escape'
        elif s['valid_drops']==0:reason='miss'
        elif s['valid_drops']!=1:reason='multiple outlet crossings'
        elif s['step']>=args.min_clean and strict_exits:reason='original-bulk delivery and target clean sequence demonstrated'
        elif s['step']==args.max_steps:reason='prespecified campaign limit reached'
        history_rows.append(dict(index=s['step'],completed=s['completed'],valid_drops=s['valid_drops'],offpath=s['offpath'],
                                 events=events,remaining=s['remaining'],peak_torque_Nm=s['peak_motor_torque_Nm']))
        write(out/'summary.json',dict(initial=info,attempted=len(history_rows),original_strict_bulk_delivered=strict_exits,
                                      rows=history_rows,stop=reason))
        return bool(reason)
    result=history(spec,fill,inertia,out/'motor',limit=.10,dt=dt,cycles=args.max_steps,stop_on=observe)
    if len(history_rows)!=len(result['steps']):
        observe(result['steps'][-1])  # solver already stopped on a mechanical fault before invoking the observer
    print('FINAL',read(out/'summary.json')['stop'],flush=True)


if __name__=='__main__':main()
