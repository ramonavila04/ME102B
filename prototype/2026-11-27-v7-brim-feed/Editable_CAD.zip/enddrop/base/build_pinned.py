"""Export the positively retained V7 canopy module, in millimeters and existing deck coordinates."""
from pathlib import Path
import os,sys
P=Path(__file__).resolve().parent;D=P
os.environ['V7_QUEUE_LEAD']='-128'
os.environ.setdefault('V7_FEED_OUTPUT',str(P/'retained_output'))
sys.path.insert(0,str(D))
import build
from retain import roof_pin,pinned_holder,metal_parts
forms_before=build.forms;parts_before=build.all_parts;orient_before=build.print_version
def complete_forms():
    parts=forms_before()
    parts['Bayonet_hopper']=pinned_holder()
    parts['Gabled_bulk_relief_canopy']=roof_pin()
    return parts
def complete_parts():
    yield from parts_before()
    for name,solid in metal_parts():
        yield name,solid,build.cq.Color(.52,.56,.59),'hardware'
def print_orientation(name,solid):
    if name=='Gabled_bulk_relief_canopy':solid=solid.rotate((0,0,0),(1,0,0),180)
    return orient_before(name,solid)
build.forms=complete_forms
build.all_parts=complete_parts
build.print_version=print_orientation
build.COLORS['Gabled_bulk_relief_canopy']=(.82,.78,.57)
for index in (1,2):
    for component in ('M3x6_flat_point_set_screw','M3_hex_nut'):
        build.COLORS[f'Canopy_{component}_{index}']=(.52,.56,.59)
if __name__=='__main__':build.build()
