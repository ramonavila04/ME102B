"""Resume the stationary five-way motor experiment after step 6, from its exact saved physical checkpoint."""
import argparse,hashlib,importlib,json,math,shutil,sys
from pathlib import Path
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('--code',type=Path,required=True,help='Folder containing the original campaign.py and imports')
parser.add_argument('--first',type=Path,required=True,help='First six-index experiment with motor/ and fill/ subdirectories')
parser.add_argument('--spec',type=Path,required=True);parser.add_argument('--inertia',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
a=parser.parse_args()
sys.path.insert(0,str(a.code.resolve())); sim=importlib.import_module('campaign')
read=lambda p: json.loads(p.read_text())
prior=read(a.first/'motor/results.json')
assert len(prior['steps'])==6 and all(s['completed'] for s in prior['steps'])
assert prior['cap_Nm']==.10 and prior['dt_s']==.0005
a.out.mkdir(parents=True,exist_ok=True)
pack=a.out/'start';pack.mkdir(exist_ok=True)
assert not (a.out/'motor/results.json').exists(),'Choose a new output directory for each replay'
src=a.first/'motor/after_6.npz'
shutil.copyfile(src,pack/'initial_pose.npz')
shutil.copyfile(a.first/'fill/fill.json',pack/'fill.json')
state=np.load(src)
t0=np.load(a.first/'fill/initial_pose.npz')
n=prior['loaded'];alive=state['active'][:n]
initial_ids=[int(e['id']) for s in prior['steps'] for e in s['events']]
assert int(alive.sum())+len(initial_ids)==n and set(np.flatnonzero(~alive))==set(initial_ids)
initial_direction=float(np.degrees(state['qpos'][0]));hist_deg=initial_direction-float(np.degrees(t0['qpos'][0]))
lineage={'station':'V7 fixed five-way upper distributor','source':'brim751 motor/after_6.npz','pack_seed':prior['seed'],'initial_filled':n,'active_at_restart':int(alive.sum()),'removed_before_restart_ids':initial_ids,'restart_sha256':sim.sha(src),'exact_start_shaft_degrees_world':initial_direction,'elapsed_first_turn_shaft_degrees':hist_deg,'first_turn_seconds':sum(s['duration_s']for s in prior['steps']),'first_turn_pose_sha256':sim.sha(a.first/'fill/initial_pose.npz'),'first_turn_motor_results_sha256':sim.sha(a.first/'motor/results.json'),'mechanical_state':'All shaft and capsule positions, quaternions, velocities, IDs and active mask restored. Closed lid. No repour, relaxation, manual wheel adjustment or refill.','numerical_state':'The original checkpoint stores qpos, qvel and active mask only. The integrated torque error, reference-speed ramp, constraint warm start and clock start afresh at the boundary after the completed post-index dwell. They are then continuous through the continuation. Local commands refer to that checkpoint actual shaft angle; offsets from the original home and full-run command numbers are given in summary.json.','impulse_cap_Nm':prior['cap_Nm'],'parent_dt_s':prior['dt_s'],'dt_s':0.00025}
sim.write(a.out/'restart.json',lineage)
result=sim.history(a.spec,pack,a.inertia,a.out/'motor',limit=prior['cap_Nm'],dt=0.00025,cycles=6)
assert result['inputs']==prior['inputs'] and result['mass_model']==prior['mass_model'] and result['friction']==prior['friction']
all_events=[e for s in result['steps'] for e in s['events']]
assert not set(initial_ids).intersection(e['id']for e in all_events)
qs=t0['qpos'][1:1+7*n].reshape(n,7)
rs=state['qpos'][1:1+7*n].reshape(n,7)
lines=[]
for s in result['steps']:
 lines.append(dict(full_index=s['step']+6,continuation_index=s['step'],start_deg_from_home=round(hist_deg+s['start_deg'],5),end_deg_from_home=round(hist_deg+s['end_deg'],5),target_encoder_degrees_from_restart=s['target_deg'],completed=s['completed'],stalled=s['stall'],timeout=s['timeout'],intended_drops=s['valid_drops'],offpath=s['offpath'],remaining=s['remaining'],peak_motor_Nm=s['peak_motor_torque_Nm'],peak_penetration_mm=s['peak_penetration_mm'],events=[dict(capsule_id=e['id'],at_degree_from_home=round(e['world_degrees']+hist_deg,5),at_index_angle=e['index_degrees'],valid=e['valid_outlet'],center_z_originally_filled_mm=round(float(qs[e['id'],2]),3),center_z_at_start_second_rev_mm=round(float(rs[e['id'],2]),3))for e in s['events']]))
sim.write(a.out/'summary.json',{'first_six_valid_outlet_counts':[s['valid_drops']for s in prior['steps']],'rows':lines,'continuous_mechanical_state':True,'initial_cups_refilled_evidence':'Compare released capsule IDs and their center elevations in the first pour versus the start of revolution two. Metering floor is z51.00 and top of the six-pocket wheel is z73.25 mm.','restart':lineage})
