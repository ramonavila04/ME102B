"""Gravity feed with housing-supported gabled bulk-relief canopy and two crescent feed windows."""
from pathlib import Path
import sys,math,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fullfeed import *
DIR=Path(__file__).resolve().parent
MOUNTS=(17,-17,163,197)
PEAK=157.8; HALF=16.; top_seat=143.25
def solidsection(pts):
    f=poly([(-34,y,z)for y,z in pts]);return S.extrudeLinear(f,[],(68,0,0))
def top(y):return PEAK-max(0.,abs(y)-1.2)
def cutoff(y):return top(y)-2.2
def canopy():
    # Width of each window 13.83, 35+ along the long axis at mid-window.
    roof=solidsection([(-HALF,top(-HALF)),(-1.2,PEAK),(1.2,PEAK),(HALF,top(HALF)),(HALF,cutoff(HALF)),(1.2,PEAK-2.2),(-1.2,PEAK-2.2),(-HALF,cutoff(-HALF))])
    # Solid below the upper skin used to terminate all four feet at its true sloping face.
    below=solidsection([(-HALF,top(-HALF)),(-1.2,PEAK),(1.2,PEAK),(HALF,top(HALF)),(HALF,top_seat-.15),(-HALF,top_seat-.15)])
    for a in MOUNTS:
        pad=sector(26.25,29.45,a-4.6,a+4.6,top_seat,PEAK).intersect(below)
        roof=roof.fuse(pad)
    return roof.intersect(cyl(29.45,136,163)).clean()
def holder():
    h=reservoir()
    # The shelf top carries the foot. One pair of side stops prevents rotational drift.
    blank=cone(29.97,29.97-.001,top_seat-5.,top_seat).cut(cone(29.84,26.0,top_seat-5.01,top_seat+.01))
    for a in MOUNTS:
        h=h.fuse(blank.intersect(sector(25.9,30.4,a-6.3,a+6.3,top_seat-5.1,top_seat+.1)))
    for a in (17-6.25,17+6.25):
        # Stops end below the roof skin and engage opposing sides of the 17° foot.
        h=h.fuse(sector(26.62,29.96,a-.6,a+.6,top_seat-.1,top_seat+1.2))
    # Clear a small top corner of the original fixed 35-degree rib at the right-hand eave.
    cutter=solidsection([(15.0,cutoff(15.)-.45),(16.45,cutoff(16.45)-.45),(16.45,147),(15.,147)])
    h=h.cut(cutter.intersect(box(22.5,25.1,14.9,16.55,139,148)))
    return h.clean()
def emit():
    fixed=holder();top_part=canopy()
    for tag,s in [('canopy',top_part),('holder',fixed)]:
        assert len(s.Solids())==1 and s.isValid(),tag
        s.exportBrep(str(DIR/(tag+'.brep')))
        s.exportStl(str(DIR/(tag+'.stl')),tolerance=.10,angularTolerance=.22)
    spec=json.loads((DIR.parent/'sim/short.json').read_text());spec['parts']['magazine']=[str(DIR/'holder.stl'),'world'];spec['parts']['canopy']=[str(DIR/'canopy.stl'),'world'];spec['highest_feed']=158.
    (DIR/'canopy.json').write_text(json.dumps(spec,indent=2))
    print('vol overlap mm3',sum(abs(s.Volume())for s in fixed.intersect(top_part).Solids()),'vertclear',round(top_part.distance(queues()),4),flush=True)
if __name__=='__main__':emit()
