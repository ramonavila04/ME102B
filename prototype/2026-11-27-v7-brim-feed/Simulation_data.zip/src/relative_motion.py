"""Measure actual body orbital motion against the rotating inlet and axial movement from archived parks."""
from pathlib import Path
import json,numpy as np
campaign=Path(__file__).parent/'brim751'
src=campaign/'fill'/'initial_pose.npz'
checkpoints=sorted((campaign/'motor').glob('after_*.npz'),key=lambda p:int(p.stem.split('_')[-1]))
n=json.loads((campaign/'fill'/'fill.json').read_text())['loaded']
def load(path):
    with np.load(path) as s:
        return float(s['qpos'][0]),s['qpos'][1:1+7*n].reshape(n,7)[:,:3],s['active'][:n]
rows=[]
for idx,fn in enumerate(checkpoints,1):
    ang1,p1,l1=load(src);ang2,p2,l2=load(fn)
    orbit=np.degrees(np.arctan2(p1[:,0]*p2[:,1]-p1[:,1]*p2[:,0],p1[:,0]*p2[:,0]+p1[:,1]*p2[:,1]))
    delta=np.degrees(ang2-ang1)
    groups={}
    for nm,z0,z1 in [('throat/cam',93.,119.5),('bulk above cam',119.5,175)]:
        mask=(l1 & l2 & (p1[:,2]>=z0) & (p1[:,2]<z1) & (np.linalg.norm(p1[:,:2],axis=1)>=9.0) & (np.linalg.norm(p2[:,:2],axis=1)>=9.0))
        if not np.any(mask):continue
        rotation=orbit[mask];descent=p2[mask,2]-p1[mask,2]
        def q(a):
            return [round(float(v),2) for v in np.quantile(a,[.1,.5,.9])]
        groups[nm]=dict(quantiles='10th, 50th, 90th percentile',count=int(mask.sum()),orbit_in_fixed_frame_deg=q(rotation),shaft_relative_orbit_deg=q(rotation-delta),vertical_movement_mm=q(descent))
    rows.append(dict(after_index=idx,shaft_travel_deg=round(delta,3),groups=groups))
    src=fn
(campaign/'orbital_motion.json').write_text(json.dumps({'method':'Endpoint-to-endpoint changes of the same bodies that remain present. Bodies inside 9-mm radius at either endpoint are excluded for ambiguous azimuth. Height groups use center height at the preceding park, not low-tip provenance. Values cannot exclude transient agitation. Shaft rotation is measured in the fixed frame.','rows':rows},indent=2))
print(json.dumps(rows[-1] if rows else {}))
