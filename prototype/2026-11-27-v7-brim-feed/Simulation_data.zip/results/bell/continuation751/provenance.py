"""Associate every outlet crossing with the capsule's starting region and original nominal pocket location."""
from pathlib import Path
import math,json,sys
import numpy as np
if len(sys.argv)!=3:raise SystemExit('python provenance.py FIRST_TURN_DIRECTORY CONTINUATION_DIRECTORY')
first,after=(Path(a) for a in sys.argv[1:])
t0=np.load(first/'fill/initial_pose.npz');turn=np.load(first/'motor/after_6.npz')
s0=json.loads((first/'motor/results.json').read_text());n=s0['loaded']
if not(after/'motor/results.json').exists():raise SystemExit('Wait for the first continuation result')
s1=json.loads((after/'motor/results.json').read_text());phi0=math.degrees(t0['qpos'][0]);phi6=math.degrees(turn['qpos'][0]);
def loc(state,mid):
 rows=state['qpos'][1:n*7+1].reshape(n,7);q=rows[mid,3:];vertical=abs(1-2*(q[1]*q[1]+q[2]*q[2]));low=rows[mid,2]-3.875-7*vertical
 a=np.radians(-90+np.arange(6)*60+math.degrees(state['qpos'][0]))
 centers=15.6*np.array([np.cos(a),np.sin(a)]).T
 nearest=float(np.min(np.linalg.norm(centers-rows[mid,:2],axis=1)));tilt=math.degrees(math.acos(np.clip(vertical,0,1)))
 return dict(center_z_mm=round(float(rows[mid,2]),3),low_tip_mm=round(float(low),3),tilt_deg=round(tilt,3),in_lower_pocket=bool(rows[mid,2]<70 and nearest<2 and tilt<=15),wholly_above_lower_meter=bool(low>73.25),wholly_above_highest_guide=bool(low>115.6048))
events=[]
for r in s1['steps']:
 for e in r['events']:
  mid=e['id'];events.append(dict(full_step=6+r['step'],id=mid,valid_outlet=e['valid_outlet'],within_step_deg=e['index_degrees'],from_original_pour=loc(t0,mid),from_second_turn=loc(turn,mid)))
d={'note':'Locations are physical model poses. A parked lower cup is within 2 mm of its nominal axis, center below z70 mm, tilt <=15 degrees. Strict upper-origin requires the entire capsule bottom tip above z115.6048 mm, the highest bell-mouth rotor surface. The bottom tip = center Z - radius - 7*abs(axis_Z).', 'steps_recorded':len(s1['steps']),'original_parked_cup_IDs':[i for i in range(n) if t0['active'][i] and loc(t0,i)['in_lower_pocket']],'second_turn_parked_cup_IDs':[i for i in range(n) if turn['active'][i] and loc(turn,i)['in_lower_pocket']],'events':events,'second_turn_releases_started_wholly_above_lower_meter_in_original_pour':sum(e['from_original_pour']['wholly_above_lower_meter']and e['valid_outlet'] for e in events),'second_turn_releases_wholly_above_highest_guide_in_original_pour':sum(e['from_original_pour']['wholly_above_highest_guide']and e['valid_outlet'] for e in events)}
(after/'drop_origins_global.json').write_text(json.dumps(d,indent=2));print(d)
