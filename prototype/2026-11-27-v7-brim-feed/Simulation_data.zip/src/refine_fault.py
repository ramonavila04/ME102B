"""Refine the first disagreed / stalled command from its immediately preceding saved park."""
from pathlib import Path
import argparse,shutil
import numpy as np
from campaign import read,write,sha,history

def main():
    p=argparse.ArgumentParser()
    for k in ('spec','inertia','original','block','out'):p.add_argument(k,type=Path)
    a=p.parse_args()
    block=a.block.resolve();orig=a.original.resolve();s=read(block/'motor/results.json');last=s['steps'][-1];i=last['step']
    assert last['stall'] or last['valid_drops']==0
    if (a.out/'motor/results.json').exists():raise RuntimeError('Choose a new refinement folder.')
    cf=orig/'fill';np_path=block/f'motor/after_{i-1}.npz' if i>1 else (block/'start/initial_pose.npz' if (block/'start/initial_pose.npz').exists() else cf/'initial_pose.npz')
    delta=(read(block/'restart.json')['prior_indices'] if (block/'restart.json').exists() else 0)
    start=a.out/'start';start.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(np_path,start/'initial_pose.npz');shutil.copyfile(cf/'fill.json',start/'fill.json')
    with np.load(np_path) as preceding,np.load(cf/'initial_pose.npz') as cold:
        start_angle=float(np.degrees(preceding['qpos'][0]-cold['qpos'][0]));remaining=int(sum(preceding['active']))
    meta=dict(global_index=delta+i,local_original_block_index=i,started_from_park=delta+i-1,
        original_payload_sha256=sha(np_path),independent_full_pose_sha256=sha(cf/'initial_pose.npz'),
        original_block_results_sha256=sha(block/'motor/results.json'),original_step=last,
        original_time_step_s=s['dt_s'],refined_time_step_s=s['dt_s']/2,cap_Nm=s['cap_Nm'],
        start_degrees_from_initial_home=start_angle,remaining_at_start=remaining,
        notes='Exact same capsule/shaft poses and velocities as preceding settled park. Reinitializes controller integral, rate ramp and numerical contact warm-start once. One local +60 degree target from measured parked position; the tiny previous residual shifts nominal home-relative target versus the original uninterrupted series. No refill/repositioning. Sensitivity check, not a replacement for the primary uninterrupted trial.')
    write(a.out/'restart.json',meta)
    new=history(a.spec.resolve(),start,a.inertia.resolve(),a.out/'motor',limit=s['cap_Nm'],dt=s['dt_s']/2,cycles=1)['steps'][0]
    assert meta['remaining_at_start']-new['remaining']==len(new['events'])
    compare=dict(global_index=delta+i,original_success=last['completed'],original_drop_count=last['valid_drops'],
        original_offpath=last['offpath'],original_stall=last['stall'],original_timed_out=last['timeout'],
        refined_success=new['completed'],refined_drop_count=new['valid_drops'],refined_offpath=new['offpath'],
        refined_stall=new['stall'],refined_timed_out=new['timeout'],refined_end_from_cold_home_deg=start_angle+new['end_deg'],
        refined_original_bulk_crossings=[ev['id'] for ev in new['events'] if ev['valid_outlet'] and ev['id'] in read(orig/'protocol.json')['strict_bulk_ids']],
        matches_count_and_completion=(last['completed'],last['valid_drops'],last['offpath'],last['stall'])==(new['completed'],new['valid_drops'],new['offpath'],new['stall']))
    write(a.out/'comparison.json',compare)
    print('REFINED',compare,flush=True)
if __name__=='__main__':main()
