"""Three identical top deck sectors. All coordinates and print dimensions are in mm."""
from functools import lru_cache
from math import cos, radians, sin
import cadquery as cq

DECK_RADIUS = 140.0
STATION_RADIUS = 96.0
SECTOR_START = 30.0
SEAM_HALF_GAP = 0.15
FOOT_CENTERS = [(-32.0, 33.0), (32.0, 33.0)]
WIRE_CENTER = (21.0, -13.0)
PRINT_NAME = 'Deck_sector_120deg'
PRINT_ROTATIONS = {PRINT_NAME: [((1, 0, 0), 180), ((0, 0, 1), 45.0)]}


def z_rotation(angle):
    return cq.Location(cq.Vector(), cq.Vector(0, 0, 1), angle)


def station(index):
    angle = index * 60.0
    a = radians(angle)
    return cq.Location(cq.Vector(-STATION_RADIUS * sin(a), STATION_RADIUS * cos(a), 0), cq.Vector(0, 0, 1), angle)


def cyl(r,z0,z1,x=0,y=0):
    return cq.Solid.makeCylinder(r,z1-z0,(x,y,z0))


def cone(r0,r1,z0,z1,x=0,y=0):
    return cq.Solid.makeCone(r0,r1,z1-z0,(x,y,z0))


def pilot_insert(x,y):
    # Nominal M3 thread minor opening simplified to a through cylinder.
    return cyl(2.5, -6, 0, x,y).cut(cyl(1.505, -6.2, .2, x,y))


def _profile():
    # XZ lathe around Z. Ø226.9 inner skirt fits over the original Ø226 housing.
    # The 3.6-mm skirt and solid outer rim reinforce the overhanging cartridge feet.
    profile = [(0,0), (139.25,0), (140,-.75), (140,-7.2), (138.7,-8.5),
               (114.1,-8.5), (113.45,-7.85), (113.45,-5), (0,-5)]
    return cq.Workplane('XZ').polyline(profile).close().revolve(360,(0,0),(0,1)).val()


def _halfplanes():
    # Shift the two seam lines in by 0.15 mm, giving a 0.30 mm assembly gap.
    lo=radians(SECTOR_START); hi=radians(SECTOR_START+120.0)
    u=(cos(lo),sin(lo)); v=(cos(hi),sin(hi))
    # Apex of the two shifted lines, along the 120° wedge bisector.
    mid=(lo+hi)/2; reach=SEAM_HALF_GAP/sin((hi-lo)/2)
    apex=(reach*cos(mid), reach*sin(mid)); L=400
    points=[apex,(apex[0]+L*u[0],apex[1]+L*u[1]),(apex[0]+L*v[0],apex[1]+L*v[1])]
    return cq.Workplane('XY').workplane(offset=-14).polyline(points).close().extrude(16).val()


def _deck_fixing(angle):
    a=radians(angle);x=100*cos(a);y=100*sin(a)
    return cyl(1.8,-6,.2,x,y).fuse(cyl(3.9,-3.7,.15,x,y),cone(3.9,4.22,-.32,0,x,y))


def _through_deck_bore(r,x,y):
    return cyl(r,-9.2,.2,x,y).fuse(cone(r,r+.4,-.4,0,x,y))


def _rounded_rectangle(w,h,r,z0,z1):
    block=cq.Workplane('XY').workplane(offset=z0).box(w,h,z1-z0, centered=(True,True,False))
    return block.edges('|Z').fillet(r).val()


def _discharge_cutter():
    # Module-local path is centered over the aperture; give it clearance on every side.
    return _rounded_rectangle(31.6,31.6,3.0,-12,.5).translate((24.68,-47.0,0))


@lru_cache(None)
def sector():
    solid=_profile().intersect(_halfplanes())
    # The housing's original UI header rises below the front skirt. Repeat its
    # clearance in every sector so all three prints are interchangeable.
    relief=cq.Solid.makeBox(107,48,4.5,(-53.5,-122.2,-9.5))
    solid=solid.cut(*(relief.moved(z_rotation(a)) for a in (0,120,240)))
    cuts=[_deck_fixing(60), _deck_fixing(120)]
    for index in range(6):
        pose=station(index)
        for x,y in FOOT_CENTERS:
            # The pocket is captive when upright; through access also clears molten flash.
            cuts.append(cyl(2.30,-9,.2,x,y).fuse(cone(2.30,2.65,-.35,0,x,y)).moved(pose))
        cuts.append(_through_deck_bore(5.0,*WIRE_CENTER).moved(pose))
        cuts.append(_discharge_cutter().moved(pose))
    return solid.cut(*cuts).clean()


def inserts_for_station():
    return [('Deck_M3x6_insert_'+str(i+1),pilot_insert(x,y),'new') for i,(x,y) in enumerate(FOOT_CENTERS)]
