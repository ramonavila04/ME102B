"""V7 three tangential end-drop tracks over six indexed metering pockets."""
from pathlib import Path
import os,sys,json,math
from functools import lru_cache
P=Path(__file__).resolve().parent
C=Path(os.environ.get('V7_BASE_CAD',str(P/'base' if (P/'base').exists() else '/private/tmp/v7_fullfeed/canopy/pinned_repro/cad')))
sys.path.insert(0,str(C));os.environ['V7_QUEUE_LEAD']='-128'
import fullfeed as f
import build
from retain import roof_pin,pinned_holder,metal_parts
import cadquery as cq
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
@lru_cache(None)
def rotor():
    s=f.lower_drum().cut(f.cyl(9.1,73.25,86)).fuse(f.cyl(5.0,73.0,86.50)).cut(f.cyl(1.76,69.8,86.60)).clean()
    return s

def profile(coords):
    w=cq.Workplane('XZ').moveTo(*coords[0])
    for point in coords[1:]:w=w.lineTo(*point) if len(point)==2 else w.threePointArc((point[0],point[1]),(point[2],point[3]))
    return w.close().revolve(360,(0,0),(0,1)).val()
def ellipse(cx,cy,z,rx,ry):
    return cq.Wire.makeEllipse(rx,ry,(cx,cy,z),(0,0,1),(1,0,0))
def end_drop_gallery():
    # Long-axis approach. The lower end of the trough points in +Y and shares the short upright well.
    # A shallow V retains the tail while the inner supporting bank recedes before the outer one.
    # Local section shapes progress uphill without internal roofs.
    sections=[(-33,130.0,0),(-27,120.7,0),(-22,115.6,0),(-17,110.5,0),(-13,106.5,.08),
              (-10,103.4,.4),(-7,100.3,.82),(-4,97.2,1),(-1,94.1,1),(2,91.0,.85),
              (5,88.0,.55),(8,91.0,.22),(12,99.0,0),(17,110.5,0),(22,123.0,0)]
    xs=(-15.,-11.,-8.,-6.,-4.,-2.,0.,2.,4.,6.,8.,11.,15.)
    side=(20.,12.,7.8,4.6,2.0,.6,0.,.6,2.0,4.6,7.8,12.,20.)
    release=(0.,3.,6.,7.3,7.0,4.5,1.5,0.,0.,0.,0.,0.,0.)
    wires=[]
    for y,lowest,relief in sections:
        pts=[(15.6+x,y,lowest+h-relief*drop) for x,h,drop in zip(xs,side,release)]
        pts.extend([(30.6,y,157),(0.6,y,157)])
        wires.append(f.poly(pts))
    # Hand-orienting tail support remains on the outward bank while the other bank recedes by 7.3 mm.
    track=f.S.makeLoft(wires,True)
    # Short upright queue, chamfered at departure to the moving cup. Its opposite-rail clear space grows upwards.
    levels=[(73.2,15.6,0.,5.12,5.12),(74.50,15.6,0.,5.00,5.00),
            (80.0,15.6,0.,5.00,5.00),(85.0,15.6,.15,5.28,5.65),(89.8,15.5,.55,5.66,6.55),
            (93.7,15.3,1.85,6.15,7.6),(98.50,15.1,3.1,6.55,8.9),(104.3,15.0,3.8,7.05,10.5),
            (110.3,15.25,3.5,9.2,13.1),(119.0,16.0,2.0,15.50,20.0),(136.0,16.0,2.0,17.,22.)]
    tip=f.S.makeLoft([ellipse(x,y,z,rx,ry)for z,x,y,rx,ry in levels],True)
    return track,tip
@lru_cache(None)
def distributor():
    # Stationary cartridge locates in V7's single keyed collar. Three 120° tracks avoid six short blind funnels.
    base=profile([(0,f.SEP_Z),(f.WELL_R,f.SEP_Z),(f.WELL_R,115.60),(28.88,116.10,28.5,116.22),
                  (22.1,113.8),(17.3,111.9),(13.6,111.9),(9.0,114.95),(4.5,118.0),(0,118.)])
    track,tip=end_drop_gallery()
    for a in (-150.,-30.,90.):
        base=base.cut(f.rot(track,a),f.rot(tip,a))
    relief=f.cyl(5.75,73.45,90).fuse(f.cone(5.75,.5,90,95.25))
    base=base.cut(relief)
    slot=f.rot(f.box(30.40,32.,-2.3,2.3,73.5,75.7),85)
    rim=f.ring(31.65,28.5,f.SEP_Z,f.SEP_TOP).cut(slot)
    s=base.fuse(rim).clean()
    assert len(s.Solids())==1 and s.isValid(),'End-drop guide must be a single solid'
    return s

def make():
    pp={key:(form, color) for key,form,color in (
        ('Pocket_metering_rotor',rotor(),(.91,.46,.15)),('Stationary_end_drop_guide',distributor(),(.26,.62,.58)),
        ('Indexed_base_sleeve',f.basewall(),(.28,.42,.44)),('Bayonet_hopper',pinned_holder(),(.72,.83,.77)),
        ('Gabled_bulk_relief_canopy',roof_pin(),(.82,.78,.57)),('Refill_lid',f.lid(),(.27,.50,.45)),
        ('Inner_race_thrust_spacer',f.ring(4.075,3.20,49.5,f.CUP_BASE),(.75,.73,.58)))}
    return pp

def physics():
    store=P/'contact';store.mkdir(exist_ok=True)
    geo={'collar':(f.basewall(),'world'),'floor':(f.ref('Ported_floor_and_bearing_carrier'),'world'),'magazine':(pinned_holder(),'world'),'roof':(distributor(),'world'),'rotor':(rotor(),'rotor'),'canopy':(roof_pin(),'world'),'hardware':(cq.Compound.makeCompound([s for n,s in metal_parts()]),'world')}
    spec={'lid':173.,'ports':[[0,-15.6]],'highest_feed':158.,'vertical_tube_measure_z':81.,'parts':{}}
    for key,(shape,domain) in geo.items():
        assert shape.isValid(),key
        shape.exportStl(str(store/(key+'.stl')),tolerance=.10,angularTolerance=.22)
        spec['parts'][key]=['contact/'+key+'.stl',domain]
        if key=='roof':shape.exportBrep(str(store/'Stationary_end_drop_guide.brep'))
    (P/'spec.json').write_text(json.dumps(spec,indent=2))
    mass=json.loads((P/'prior_inertia.json').read_text());rows=[r for r in mass['rows'] if r['part'] not in ('Vertical_queue_rotor','Pocket_metering_rotor')]
    prop=GProp_GProps();BRepGProp.VolumeProperties_s(rotor().wrapped,prop);com=prop.CentreOfMass();v=prop.Mass();rho=.00124
    rows.append(dict(part='Pocket_metering_rotor',density_g_cm3=1.24,volume_mm3=v,mass_g=v*rho,axis_moment_gmm2=(prop.MatrixOfInertia().Value(3,3)+v*(com.X()**2+com.Y()**2))*rho,z_cm_mm=com.Z()))
    mass.update(rows=rows,total_mass_g=sum(r['mass_g'] for r in rows),total_kg_m2=sum(r['axis_moment_gmm2'] for r in rows)*1e-9)
    mass['com_z_mm']=sum(r['z_cm_mm']*r['mass_g'] for r in rows)/mass['total_mass_g'];(P/'inertia.json').write_text(json.dumps(mass,indent=2))
def export():
    pp=make()
    forms_before=build.forms;all_before=build.all_parts;print_before=build.print_version
    build.forms=lambda:{key:v[0] for key,v in pp.items()}
    build.COLORS.update({key:v[1] for key,v in pp.items()})
    def allparts():
        yield from all_before()
        for name,s in metal_parts():yield name,s,cq.Color(.52,.56,.59),'hardware'
    build.all_parts=allparts
    def printable(n,s):
        if n=='Gabled_bulk_relief_canopy':s=s.rotate((0,0,0),(1,0,0),180)
        return print_before(n,s)
    build.print_version=printable;build.DEST=P/'release';build.build()
    from print_mesh import finish
    finish(build.DEST)
if __name__=='__main__':
    physics() if 'contact' in sys.argv else export()
