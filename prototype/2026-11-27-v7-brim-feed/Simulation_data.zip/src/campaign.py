"""Run a genuine random bulk pour, then consecutive 60-degree commands with finite shaft torque.

All geometry and coordinates in millimeters, internal mass grams and time seconds.
Arm rotation during commands is advanced only by the MuJoCo integrator from applied torque.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import time
import numpy as np
import mujoco as mj
from audit_helpers import details,torque_sources
from closedfeed import cached, axis
from study import run as gravity_pour

def write(path,obj):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2));tmp.replace(path)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text())
def history(spec_file,pack_dir,mass_file,out,limit=.10,dt=.00050,cycles=6):
    out.mkdir(parents=True,exist_ok=True)
    pack=read(pack_dir/'fill.json'); state=np.load(pack_dir/'initial_pose.npz'); n=pack['loaded']
    spec=read(spec_file)
    for node in spec['parts'].values():
        node[0]=str((spec_file.resolve().parent/node[0]).resolve())
    live=state['active'][:n].copy()
    m=cached(spec,n,pack['body_od'],pack['friction'],dt);d=mj.MjData(m)
    inertia=read(mass_file); rb=m.body('rotor').id
    m.body_mass[rb]=inertia['total_mass_g']
    m.body_ipos[rb]=[0.,0.,inertia['com_z_mm']]
    m.body_inertia[rb,:]=inertia['total_kg_m2']*1e9
    for i in range(n):m.body_gravcomp[m.body(f'p{i}').id]=0. if live[i] else 1.
    mj.mj_setConst(m,d)
    d.qpos[:]=state['qpos'][:m.nq];d.qvel[:]=state['qvel'][:m.nv]
    d.mocap_pos[0]=[0.,0.,0.]
    mj.mj_forward(m,d)
    assert abs(d.qM[0]*1e-9 /inertia['total_kg_m2']-1.)<1e-5
    enc0=float(d.qpos[0]);bids=np.asarray([m.body(f'p{i}').id for i in range(n)])
    q=np.array([m.jnt_qposadr[m.joint(f'f{i}').id] for i in range(n)])[:,None]+np.arange(7)
    v=np.array([m.jnt_dofadr[m.joint(f'f{i}').id] for i in range(n)])[:,None]+np.arange(6)
    outlet=spec['ports'][0]; z_out=spec.get('floor',51.)-21.75/2-1
    tau_i=0.;rate_ref=0.;vmax=math.radians(18); kpos=6.;kv=.015;ki=.40; accel=5.
    log=[];traj=[];steps=[];all_events=[];t0=time.monotonic()
    summary=dict(seed=pack['seed'],friction=pack['friction'],engine=mj.__version__,dt_s=dt,cap_Nm=limit,loaded=n,early_drops=pack['early_drops'],lid_freeboard_mm=pack['lid_freeboard_mm'],mass_model=inertia,inputs={name:sha(Path(val[0])) for name,val in spec['parts'].items()},pose_sha256=sha(pack_dir/'initial_pose.npz'),steps=steps,attempted=0,requested=cycles,completed=0,singles_on_completed=0,valid_drops=0,offpath=0,complete_single_per_step=False)
    next_log=0.;next_frame=0.; total_t=0.
    for step in range(1,cycles+1):
        before=int(live.sum());target=enc0+math.radians(60*step)
        stable=0.;stall=0.;max_stall=0.;settled=None;peak_pen=0.;peak_motor=0.;peak_reaction=0.;max_pen_detail=None;stalled=False;timeout=False;events=[];torques=[]
        start_angle=math.degrees(float(d.qpos[0])-enc0);time_sat=0.;t=0.;local_0=total_t
        while t<8.55:
            ang=float(d.qpos[0]);w=float(d.qvel[0])
            desired=max(-vmax,min(vmax,kpos*(target-ang)))
            rate_ref+=max(-accel*dt,min(accel*dt,desired-rate_ref))
            ve=rate_ref-w;new_i=tau_i+ki*ve*dt;p=kv*ve
            if abs(p+new_i)<=limit or (p+new_i)*ve<0:tau_i=new_i
            tau=max(-limit,min(limit,p+tau_i));drag=.002*math.tanh(w/.08)+.0005*w
            d.qfrc_applied[0]=(tau-drag)*1e9
            mj.mj_step(m,d)
            total_t+=dt;t=total_t-local_0; shaft=math.degrees(float(d.qpos[0])-enc0)
            rate=math.degrees(float(d.qvel[0]));reaction=abs(float(d.qfrc_constraint[0]))*1e-9
            if abs(tau)>.999*limit:time_sat+=dt
            peak_motor=max(peak_motor,abs(tau));peak_reaction=max(peak_reaction,reaction);torques.append(abs(tau))
            if d.ncon:
                deepest=int(np.argmin(d.contact.dist))
                if -d.contact[deepest].dist>peak_pen:
                    peak_pen=float(-d.contact[deepest].dist)
                    max_pen_detail=dict(t_s=round(total_t,4),**details(m,d.contact[deepest]))
            stable=stable+dt if abs(60*step-shaft)<=.30 and abs(rate)<=1 else 0.
            if settled is None and stable>=.15:settled=t
            stall=stall+dt if abs(rate)<1 and abs(math.degrees(desired))>9 and abs(tau)>=.9*limit else 0.
            max_stall=max(max_stall,stall)
            for i in np.flatnonzero(live & (d.xpos[bids,2]<z_out)):
                x,y,z=d.xpos[bids[i]];u=axis(d.qpos[q[i,3:]][None,:])[0]
                ok=bool(np.hypot(max(abs(x-outlet[0])-8.,0.),y-outlet[1])<=7.)
                event=dict(step=step,id=int(i),time_s=round(total_t,4),world_degrees=round(shaft,4),index_degrees=round(shaft-60*(step-1),4),xyz=[round(float(a),4) for a in (x,y,z)],valid_outlet=ok,tilt_degrees=round(math.degrees(math.acos(np.clip(abs(u[2]),0,1))),4))
                events.append(event);all_events.append(event);live[i]=False;m.body_gravcomp[bids[i]]=1.
                d.qpos[q[i,:3]]=[500+i*30,300,100];d.qvel[v[i]]=0.
            if total_t>=next_log:
                log.append(dict(step=step,seconds=round(total_t,5),shaft_deg=round(shaft,5),rate_deg_s=round(rate,5),motor_Nm=round(tau,6),contact_Nm=round(reaction,6)))
                next_log+=.05
            if total_t>=next_frame:
                ids=np.flatnonzero(live);poses=d.qpos[q[ids]]
                traj.append(dict(step=step,seconds=round(total_t,3),angle=round(shaft,3),ids=ids.tolist(),xyz=poses[:,:3].round(3).tolist(),axis=axis(poses[:,3:]).round(3).tolist(),released=[e['id'] for e in all_events if e['valid_outlet']]))
                next_frame+=.12
            if settled is not None and t>=settled+.55:break
            if stall>=1.0:stalled=True;break
            if settled is None and t>=8.:timeout=True;break
        assert int(live.sum())+len(events)==before
        end_ok=settled is not None and abs(60*step-shaft)<=.30 and abs(rate)<=1 and not(stalled or timeout)
        result=dict(step=step,start_deg=round(start_angle,5),target_deg=60*step,end_deg=round(shaft,5),duration_s=round(t,5),completed=end_ok,stall=stalled,timeout=timeout,peak_motor_torque_Nm=round(peak_motor,6),p95_motor_torque_Nm=round(float(np.percentile(torques,95)),6),time_at_cap_s=round(time_sat,4),peak_contact_torque_Nm=round(peak_reaction,6),peak_penetration_mm=round(peak_pen,5),deepest_contact=max_pen_detail,longest_stall_s=round(max_stall,5),valid_drops=sum(e['valid_outlet'] for e in events),offpath=sum(not e['valid_outlet'] for e in events),remaining=int(live.sum()),events=events)
        if not end_ok and d.ncon:result['last_rotor_contacts']=torque_sources(m,d)
        steps.append(result);summary['attempted']=len(steps);summary['completed']=sum(k['completed'] for k in steps)
        summary['valid_drops']=sum(e['valid_outlet'] for e in all_events);summary['offpath']=len(all_events)-summary['valid_drops']
        summary['singles_on_completed']=sum(k['completed'] and k['valid_drops']==1 and k['offpath']==0 for k in steps)
        summary['complete_single_per_step']=summary['singles_on_completed']==cycles and pack['early_drops']==0
        write(out/'results.json',summary);write(out/'telemetry.json',log);write(out/'trajectory.json',traj)
        np.savez_compressed(out/f'after_{step}.npz',qpos=d.qpos,qvel=d.qvel,active=live)
        print(out.parent.name,out.name,'step',step,'of',cycles,'completed',end_ok,'angle',round(shaft,2),'drop',result['valid_drops'],'other',result['offpath'],'wall',round(time.monotonic()-t0,2),flush=True)
        if not end_ok:break
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('spec',type=Path);p.add_argument('inertia',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--seed',type=int,default=750);p.add_argument('--mu',type=float,default=.32);p.add_argument('--dt',type=float,default=.0005);p.add_argument('--cycles',type=int,default=6);p.add_argument('--pourdt',type=float,default=.0015);p.add_argument('--pack',type=Path);p.add_argument('--cap',type=float,default=.10)
    a=p.parse_args();pack=a.pack or a.out/'fill'
    if not a.pack:gravity_pour(a.spec,pack,seed=a.seed,mu=a.mu,dt=a.pourdt,cycles=0)
    history(a.spec,pack,a.inertia,a.out/'motor',a.cap,a.dt,a.cycles)
