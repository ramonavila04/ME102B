"""Track initially wholly-above-crown capsules from the pour to the outlet without guessing provenance."""
import argparse,json,math
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('first',type=Path);p.add_argument('continuation',type=Path);a=p.parse_args();read=lambda q:json.loads(q.read_text());n=read(a.first/'motor/results.json')['loaded'];s=np.load(a.first/'fill/initial_pose.npz');q=s['qpos'][1:1+7*n].reshape(n,7);vz=np.abs(1-2*(q[:,4]**2+q[:,5]**2));low=q[:,2]-3.875-7*vz;ids=set(map(int,np.flatnonzero((low>116.8)&s['active'][:n]))); names=sorted(ids);events=[];depths={k:[] for k in names};entries={}
def add(k,g,t,z,v,source):
 tip=float(z-3.875-7*abs(v));depths[k].append((tip,float(z),g,t,source,k));
for k in names:add(k,0,0,q[k,2],vz[k],'initial pose')
for off,folder in [(0,a.first),(6,a.continuation)]:
 tr=read(folder/'motor/trajectory.json');rs=read(folder/'motor/results.json');xsum=0
 for f in tr:
  for k,xyz,ax in zip(f['ids'],f['xyz'],f['axis']):
   if k in ids:add(k,f['step']+off,f['seconds'],xyz[2],ax[2],'120 ms pose')
 for st in rs['steps']:
  g=off+st['step'];xsum+=st['duration_s'];snap=np.load(folder/f"motor/after_{st['step']}.npz");q=snap['qpos'][1:1+7*n].reshape(n,7)
  for k in names:
   if snap['active'][k]:add(k,g,xsum,q[k,2],1-2*(q[k,4]**2+q[k,5]**2),'index endpoint')
  for e in st['events']:
   if e['id'] in ids:
    events.append(dict(step=g,id=e['id'],time_s=e['time_s'],valid=e['valid_outlet'],index_deg=e['index_degrees'],initial_low_tip_mm=round(float(low[e['id']]),3),event_xyz_mm=e['xyz']));add(e['id'],g,e['time_s'],e['xyz'][2],math.cos(math.radians(e['tilt_degrees'])),'crossing')
def summarize(items):
 if not items:return None
 low=min(items);byz=min(items,key=lambda x:x[1]);return dict(min_obs_low_tip_mm=round(low[0],3),record_at_min_tip=dict(id=low[5],center_z_mm=round(low[1],3),global_step=low[2],local_block_seconds=round(low[3],3),source=low[4]),min_obs_center_mm=round(byz[1],3),ID_at_min_center=byz[5])
all_poses=[v for seq in depths.values() for v in seq];maxg=max(v[2] for v in all_poses);out={'definition':'Original gravity-settled lower capsule tip exceeds z116.8 mm. Capsule cylindrical half-axis 7 mm, radius 3.875 mm. Minima are observed among 120 ms frames, exact index endpoints and logged crossings. Between-frame excursions may be missed. Frame-derived tip positions use rounded axis and XYZ; nominal tip uncertainty up to ~0.004 mm. Times reset upon integrator restart after global index 6.','loaded':n,'original_strict_bulk_count':len(names),'original_strict_bulk_ids':names,'steps_recorded':maxg,'valid_upper_origin_crossings':[e for e in events if e['valid']],'offpath_upper_origin_crossings':[e for e in events if not e['valid']],'original_upper_capsules_lowest_each_global_step':{str(k):summarize([v for v in all_poses if v[2]==k]) for k in range(maxg+1)},'during_continuation':summarize([v for v in all_poses if v[2]>6]),'minimum_per_original_bulk_id_entire_run':{str(k):summarize(v) for k,v in depths.items()}};(a.continuation/'strict_bulk_tracking.json').write_text(json.dumps(out,indent=2)+'\n');print('Original strict-bulk count',len(names),'through index',maxg,'bulk events',events,'second turn lowest',out['during_continuation']);
