"""Verify all packaged absolute path-independent CAD hashes and each saved simulation starting state."""
import argparse,hashlib,json,posixpath
from zipfile import ZipFile
from pathlib import Path
def verify(archive):
    with ZipFile(archive) as z:
        assert z.testzip() is None
        files=set(z.namelist());specs={};checked=0;states=0
        for sp in sorted(x for x in files if x.startswith('cases/') and x.endswith('/spec.json')):
            cases=sp.split('/')[1];geometry={}
            for part,(ref,_) in json.loads(z.read(sp))['parts'].items():
                assert not ref.startswith('/')
                payload=z.read(posixpath.normpath(posixpath.join(posixpath.dirname(sp),ref)))
                geometry[part]=hashlib.sha256(payload).hexdigest()
            specs[cases]=geometry
        for rp in sorted(x for x in files if x.startswith('results/') and x.endswith('/motor/results.json')):
            name=rp.split('/')[1];base=rp[:-len('motor/results.json')];res=json.loads(z.read(rp))
            assert res['inputs']==specs[name],rp;checked+=1
            pose=next((x for x in [base+'fill/initial_pose.npz',base+'start/initial_pose.npz'] if x in files),None)
            if pose:assert res['pose_sha256']==hashlib.sha256(z.read(pose)).hexdigest(),rp;states+=1
        for line in z.read('SHA256SUMS.txt').decode().splitlines():
            h,k=line.split('  ',1);assert h==hashlib.sha256(z.read(k)).hexdigest()
        print('Verified',len(files),'files',len(specs),'mesh sets',checked,'simulation geometry digests',states,'starting poses')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('archive',type=Path);verify(p.parse_args().archive)
