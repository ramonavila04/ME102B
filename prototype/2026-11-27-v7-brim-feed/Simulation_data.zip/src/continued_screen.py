"""Continue a six-index run from its real settled endpoint to the first failed index or proven original bulk delivery."""
from pathlib import Path
import argparse,shutil,math
import numpy as np
from campaign_bounded import history,write,read,sha
p=argparse.ArgumentParser()
for k in ('spec','inertia','original','out'):p.add_argument(k,type=Path)
p.add_argument('--crown',type=float,required=True)
p.add_argument('--dt',type=float,default=.00025)
a=p.parse_args();orig=a.original.resolve();out=a.out.resolve();prior=read(orig/'motor/results.json');cold=orig/'fill/initial_pose.npz'
assert prior['complete_single_per_step'] and prior['requested']==6 and prior['early_drops']==0
if (out/'motor/results.json').exists():raise RuntimeError('Use a new output folder.')
start=out/'start';start.mkdir(exist_ok=True,parents=True);source=orig/'motor/after_6.npz'
shutil.copyfile(source,start/'initial_pose.npz');shutil.copyfile(orig/'fill/fill.json',start/'fill.json')
n=prior['loaded']
with np.load(cold) as initial, np.load(source) as restart:
    q=initial['qpos'][1:1+7*n].reshape(n,7).copy();offset=float(np.degrees(restart['qpos'][0]-initial['qpos'][0]))
    remain=int(sum(restart['active']));assert remain==n-6
tip=q[:,2]-3.875-7*np.abs(1-2*(q[:,4]**2+q[:,5]**2));strict=set(np.flatnonzero(tip>a.crown).tolist())
delivered={e['id'] for s in prior['steps'] for e in s['events']};strict_ids=sorted(delivered & strict)
meta=dict(prior_indices=6,original_loaded=n,seed=prior['seed'],mu=prior['friction'],global_home_offset_deg=offset,original_pour_sha256=sha(cold),after_6_sha256=sha(source),first_block_sha256=sha(orig/'motor/results.json'),initial_strict_bulk_ids=sorted(strict),strict_low_tip_above_z_mm=a.crown,
          already_delivered_6_ids=sorted(delivered),remaining_at_start=remain,drive_dt_s=a.dt,cap_Nm=prior['cap_Nm'],
          stop='Global 7–18. Stop after first defective step, or after any truly original-bulk exit plus at least 13 consecutive clean park intervals, or at 18.',
          restart='Retain exact physical positions, velocities and membership from original after_6. One reset of PI integral, rate ramp, simulated contact warmstart and clock. Subsequent commands use continuous controls.')
write(out/'restart.json',meta);rows=[]
def record(s):
    for e in s['events']:
        assert e['id'] not in delivered;delivered.add(e['id'])
        if e['valid_outlet'] and e['id'] in strict:strict_ids.append(e['id'])
    i=6+s['step']
    if not s['completed']:reason='stall' if s['stall'] else 'motion failed to settle'
    elif s['offpath']:reason='off-path escape'
    elif s['valid_drops']==0:reason='miss'
    elif s['valid_drops']!=1:reason='multiple releases'
    elif i>=13 and strict_ids:reason='original-bulk delivery and 13 clean indexes demonstrated'
    elif i==18:reason='prespecified 18-command ceiling'
    else:reason=''
    rows.append(dict(index=i,completed=s['completed'],global_home_end_deg=round(offset+s['end_deg'],5),valid_drops=s['valid_drops'],offpath=s['offpath'],remaining=s['remaining'],peak_torque_Nm=s['peak_motor_torque_Nm'],peak_penetration_mm=s['peak_penetration_mm'],
        events=[dict(id=e['id'],was_original_bulk=e['id'] in strict,initial_low_tip_z_mm=round(float(tip[e['id']]),4),through_outlet=e['valid_outlet']) for e in s['events']]))
    write(out/'summary.json',dict(rows=rows,original_bulk_exit_ids=strict_ids,stop=reason));return bool(reason)
r=history(a.spec.resolve(),start,a.inertia.resolve(),out/'motor',limit=prior['cap_Nm'],dt=a.dt,cycles=12,stop_on=record)
if len(rows)!=len(r['steps']):record(r['steps'][-1])
assert prior['inputs']==r['inputs']
print('FINAL',read(out/'summary.json')['stop'],flush=True)
