"""Generate the local-coordinate station STEP and oriented production meshes."""
import csv,shutil,math
from fullfeed import *
DEST=Path(os.environ.get('V7_FEED_OUTPUT',str(ROOT/'output')))
COLORS={'Pocket_metering_rotor':(.93,.46,.19),'Vertical_queue_rotor':(.96,.62,.31),
        'Keyed_cutoff_shelf':(.15,.49,.48),'Indexed_base_sleeve':(.28,.42,.44),
        'Bayonet_hopper':(.72,.83,.77),'Refill_lid':(.27,.50,.45),'Inner_race_thrust_spacer':(.75,.73,.58)}
def forms():return {'Pocket_metering_rotor':lower_drum(),'Vertical_queue_rotor':queues(),'Keyed_cutoff_shelf':keeper(),
                   'Indexed_base_sleeve':basewall(),'Bayonet_hopper':reservoir(),'Refill_lid':lid(),'Inner_race_thrust_spacer':ring(4.075,3.20,49.50,CUP_BASE)}
SKIP={'Six_flute_end_first_rotor','Keyed_separator','Stationary_flute_liner','Refill_hopper','Piloted_lid'}
def all_parts():
    prior=json.loads((REF/'inventory.json').read_text())
    for line in prior:
        n=line['name']
        if n in SKIP:continue
        s=ref(n)
        if n=='Axial_retainer_M3x20':s=s.translate((0,0,1.))
        yield n,s,cq.Color(*line['color'][:3]),line['kind']
    for n,s in forms().items():
        yield n,s,cq.Color(*COLORS[n]),'print'
def print_version(n,s):
    if n=='Clamping_hub':
        a=math.radians(12)
        s=s.rotate((0,0,0),(-math.cos(a),math.sin(a),0),90)
    if n in ('Ported_floor_and_bearing_carrier','Refill_lid'):
        s=s.rotate((0,0,0),(1,0,0),180)
    b=s.BoundingBox()
    return s.translate((-(b.xmin+b.xmax)/2,-(b.ymin+b.ymax)/2,-b.zmin))
def build():
    DEST.mkdir(exist_ok=True,parents=True);meshes=DEST/'stl';meshgeom=DEST/'brep'
    meshes.mkdir(exist_ok=True);meshgeom.mkdir(exist_ok=True)
    ass=cq.Assembly(name='V7_two_stage_vertical_queue_module')
    inventory=[]
    for n,s,c,kind in all_parts():
        assert s.isValid() and len(s.Solids())==1,n
        ass.add(s,name=n,color=c)
        s.exportBrep(str(meshgeom/(n+'.brep')))
        if kind=='print':
            print_version(n,s).exportStl(str(meshes/(n+'.stl')),tolerance=.045,angularTolerance=.12)
        inventory.append(dict(name=n,kind=kind,revision=('new' if n in COLORS else 'retained'),color=c.toTuple(),volume_mm3=s.Volume()))
        print('Export',n,flush=True)
    (DEST/'inventory.json').write_text(json.dumps(inventory,indent=2))
    ass.export(str(DEST/'V7_Vertical_Queue_Module.step'))
    with ZipFile(DEST/'V7_Vertical_Queue_Print_Parts.zip','w',ZIP_DEFLATED) as z:
        for f in sorted(meshes.glob('*.stl')):z.write(f,f.name)
if __name__=='__main__':build()
