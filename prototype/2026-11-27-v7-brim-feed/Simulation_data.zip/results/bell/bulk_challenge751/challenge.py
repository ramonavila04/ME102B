"""No-refill challenge of the bell feed after two completed turns. Maintains the same motor between these commands."""
import argparse,json,sys,shutil,hashlib
from pathlib import Path
import numpy as np
parser=argparse.ArgumentParser()
for n in ['code','first','second','spec','inertia','out']:parser.add_argument('--'+n,type=Path,required=True)
a=parser.parse_args();sys.path.insert(0,str(a.code.resolve()))
from campaign_bounded import history,write,read,sha
p=a.out;p.mkdir(exist_ok=True,parents=True); start=p/'start';start.mkdir(exist_ok=True); mot=p/'motor'
assert not(mot/'results.json').exists(),'replay in a fresh directory'
r0=read(a.first/'motor/results.json');r1=read(a.second/'motor/results.json')
assert all(r['complete_single_per_step'] and len(r['steps'])==6 for r in [r0,r1])
assert r0['inputs']==r1['inputs'] and r0['mass_model']==r1['mass_model'] and r0['cap_Nm']==r1['cap_Nm']==.10 and r0['dt_s']==r1['dt_s']==.0005
original=np.load(a.first/'fill/initial_pose.npz');prior=np.load(a.second/'motor/after_6.npz');n=r0['loaded']
q0=original['qpos'][1:7*n+1].reshape(n,7);tilt_cos=np.abs(1-2*(q0[:,4]**2+q0[:,5]**2))
tip=q0[:,2]-7*tilt_cos-3.875; crown=115.6048;bulk=set(np.flatnonzero(tip>crown).tolist())
loss={e['id']for r in [r0,r1] for s in r['steps']for e in s['events']};assert len(loss)==12 and sum(prior['active'][:n])==n-12 and loss.isdisjoint(np.flatnonzero(prior['active'][:n]).tolist())
shutil.copyfile(a.first/'fill/fill.json',start/'fill.json');shutil.copyfile(a.second/'motor/after_6.npz',start/'initial_pose.npz')
restart={'station':'V7 rotating bell-mouth queue','initial_N':n,'at_start_command_13':n-12,'original_bulk_capsule_ids':sorted(bulk),'original_bulk_rule':'Lowest tip strictly above highest as-built nominal inlet surface (115.6048 mm).','after_global_12_sha256':sha(start/'initial_pose.npz'),'original_pack_sha256':sha(a.first/'fill/initial_pose.npz'),'first_turn_results_sha256':sha(a.first/'motor/results.json'),'second_turn_results_sha256':sha(a.second/'motor/results.json'),'start_angle_world_deg':float(np.degrees(prior['qpos'][0])),'degrees_from_original_home':float(np.degrees(prior['qpos'][0]-original['qpos'][0])),'cap_Nm':.1,'timestep_s':.0005,'watch':'Complete at most six consecutive new index commands without refill. Stop after first above-crown original capsule crosses intended outlet, first count other than exactly one, any off-path outlet crossing or any motor fault. Stopping decisions follow completion/dwell or original fault guard.','state':'Exact body positions, orientations, velocities and active IDs from stored second-turn after_6. Torque integral, rate ramp, engine time and numerical contact warm start reset after completed post-index dwell. These control quantities remain continuous through this group.'};write(p/'restart.json',restart)
def stop_reason(s):
    if not s['completed']:return 'motor stall' if s['stall'] else ('motor settle timeout' if s['timeout'] else 'motor completion fault')
    if s['offpath']:return 'off-path release'
    if s['valid_drops']==0:return 'miss'
    if s['valid_drops']>1:return 'multiple releases'
    if any(e['valid_outlet'] and e['id'] in bulk for e in s['events']):return 'original above-crown capsule delivered'
    return None
def record(r):
    rows=[];hits=[]
    for s in r['steps']:
        events=[{'id':e['id'],'strict_bulk':e['id'] in bulk,'initial_z_mm':round(float(q0[e['id'],2]),3),'initial_low_tip_mm':round(float(tip[e['id']]),3),'initial_tilt_deg':round(float(np.degrees(np.arccos(np.clip(tilt_cos[e['id']],0.,1.)))),3),'valid':e['valid_outlet'],'drop_index_angle_deg':e['index_degrees']} for e in s['events']]
        hits+=[e['id']for e in events if e['valid'] and e['strict_bulk']]
        rows.append(dict(global_command=12+s['step'],completed=s['completed'],intended_count=s['valid_drops'],off_path_count=s['offpath'],events=events,remaining=s['remaining'],peak_motor_Nm=s['peak_motor_torque_Nm'],end_from_home_deg=round(restart['degrees_from_original_home']+s['end_deg'],5),peak_penetration_mm=s['peak_penetration_mm']))
    finish=stop_reason(r['steps'][-1]) or 'all six commands completed without a qualifying above-crown crossing'
    write(p/'summary.json',{'stop_condition':finish,'command_rows':rows,'strict_bulk_releases':hits,'restart':restart})
r=history(a.spec,start,a.inertia,mot,.10,.0005,6,lambda s:bool(stop_reason(s)))
assert r['inputs']==r0['inputs'] and r['mass_model']==r0['mass_model']
record(r)
