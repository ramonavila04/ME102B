"""Build the printable six-cartridge prototype from the supplied V7 reference assembly.

Python 3.12, CadQuery 2.8 and millimetres. Examples are included in README.txt.
"""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZIP_DEFLATED
import json
import os
import cadquery as cq
import deck


def components(assembly):
    return {tuple(path.split('/')[1:]):(shape,loc,col) for shape,path,loc,col in assembly}


def keep_v7(key):
    group,name=key
    return (not group.startswith('Dispensing_module_') and
            not (group=='Station_fasteners' and name.startswith('Module_')) and
            key != ('Enclosure','Top_deck'))


def color(n,kind='print'):
    s=n.lower()
    if n==deck.PRINT_NAME:rgb=(54,77,84)
    elif 'insert' in s:rgb=(206,155,73)
    elif 'gearmotor' in s:rgb=(174,141,78)
    elif kind in ('new','reuse'):rgb=(153,166,167)
    elif 'lid' in s:rgb=(62,125,120)
    elif 'magazine' in s:rgb=(194,213,203)
    elif any(i in s for i in ('disc','jaw','wheel')):rgb=(219,151,75)
    elif any(i in s for i in ('guide','chute','flume','duct','delivery')):rgb=(88,132,134)
    elif 'plate' in s:rgb=(103,137,142)
    else:rgb=(78,102,110)
    return cq.Color(*[v/255 for v in rgb])


def prep_assets(reference,folder):
    import drive26
    folder.mkdir(parents=True,exist_ok=True)
    for name in drive26.REF_NAMES:
        sh,loc,col=reference['Dispensing_module_01',name]
        cq.exporters.export(sh,str(folder/(name+'.step')))
    os.environ['PILL_MOTOR_ASSETS']=str(folder)


def design():
    import head26,drive26,guide26
    sources=[head26, drive26, guide26]
    parts=[row for source in sources for row in source.parts()]
    names=[name for name,shape,kind in parts]
    if len(names)!=len(set(names)):
        raise ValueError('Each CAD component needs its own name.')
    shelf=deck.sector()
    rotations={'Outer_race_spacing_sleeve':[((0,0,1),-180),((1,0,0),-50)]}
    for source in [*sources,deck]:rotations.update(getattr(source,'PRINT_ROTATIONS',{}))
    return parts,shelf,rotations


def on_bed(shape,rotations):
    obj=shape
    for axis,angle in rotations:obj=obj.rotate((0,0,0),axis,angle)
    box=obj.BoundingBox()
    return obj.translate((-(box.xmin+box.xmax)/2,-(box.ymin+box.ymax)/2,-box.zmin))


def make_assemblies(parts,shelf,reference):
    single=cq.Assembly(name='Serviceable_canister')
    for n,s,k in parts:single.add(s,name=n,color=color(n,k))
    original_colors=json.loads((Path(__file__).parent/'reference_colors.json').read_text())
    groups=defaultdict(dict)
    for key,(s,loc,col) in reference.items():
        if keep_v7(key):groups[key[0]][key[1]]=s,loc,col or cq.Color(*original_colors['/'.join(key)])
    for i in range(3):
        groups['Top_deck']['Interchangeable_deck_sector_'+str(i+1)]=(shelf,deck.z_rotation(i*120),color(deck.PRINT_NAME))
    for i in range(6):
        station=deck.station(i)
        for n,s,k in parts:
            groups[f'Dispensing_module_{i+1:02}'][n]=s,station,color(n,k)
        for n,s,k in deck.inserts_for_station():
            groups['Top_deck'][f'Station_{i+1}_{n}']=s,station,color(n,k)
    full=cq.Assembly(name='Automatic_pill_dispenser')
    for group,rows in groups.items():
        sub=cq.Assembly(name=group)
        for n,(s,loc,col) in rows.items():sub.add(s,name=n,loc=loc,color=col)
        full.add(sub)
    return single,full


def write_models(output,parts,shelf,rotations,reference,staging):
    for n,s,k in parts+[(deck.PRINT_NAME,shelf,'print')]:
        if not s.isValid() or len(s.Solids())!=1 or s.Volume()<=0:
            raise ValueError(f'Invalid solid: {n}')
    single,full=make_assemblies(parts,shelf,reference)
    single.export(str(staging/'Single_Canister.step'))
    full.export(str(staging/'Six_Canister_Dispenser.step'))
    meshes={n:(s,6) for n,s,k in parts if k=='print'}
    meshes[deck.PRINT_NAME]=(shelf,3)
    with ZipFile(staging/'Print_Parts.zip','w',ZIP_DEFLATED,compresslevel=4) as z:
        for n,(s,qty) in meshes.items():
            solid=on_bed(s,rotations.get(n,[])); dims=solid.BoundingBox()
            if max(dims.xlen,dims.ylen,dims.zlen)>220.01:
                raise ValueError(f'{n} exceeds the 220 mm print envelope')
            file=staging/(n+'.stl')
            solid.exportStl(str(file),tolerance=.035,angularTolerance=.11,relative=False)
            folder='Shared_deck' if n==deck.PRINT_NAME else 'One_of_each_per_canister'
            z.write(file,f'{folder}/{n}_qty{qty}_for_full_build.stl')
    output.mkdir(parents=True,exist_ok=True)
    for name in ('Single_Canister.step','Six_Canister_Dispenser.step','Print_Parts.zip'):
        (staging/name).replace(output/name)


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('--v7',type=Path,default=Path('Pill_Dispenser_V7_Heat_Inserts.step'))
    p.add_argument('--out',type=Path,default=Path('build'))
    args=p.parse_args();v7=args.v7.resolve();output=args.out.resolve()
    if not v7.is_file():p.error('Supply the original Pill_Dispenser_V7_Heat_Inserts.step with --v7.')
    original=cq.Assembly.load(str(v7),'STEP');reference=components(original)
    if ('Enclosure','Top_deck') not in reference or ('Dispensing_module_01','Drive_shaft') not in reference:
        p.error('The input needs the original named V7 assembly structure.')
    os.environ['PILL_V7_STEP']=str(v7);output.mkdir(parents=True,exist_ok=True)
    with TemporaryDirectory(prefix='.canister_build_',dir=output) as tmp:
        work=Path(tmp);prep_assets(reference,work/'hardware')
        parts,section,rotations=design()
        write_models(output,parts,section,rotations,reference,work)
    print(f'Exported {len(parts)} component definitions and three deck sectors to {output}')

if __name__=='__main__':main()
