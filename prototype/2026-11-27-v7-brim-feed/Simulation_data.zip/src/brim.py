"""Top off a settled loose-pour pack with single free capsules; test seated lid and pilot clearance.

A trial insertion is rejected if the finished pack cannot be closed. Capsules already accepted
are carried along untouched; the candidate location/orientation is never adjusted after release.
"""
from pathlib import Path
import argparse,math,json
import numpy as np
import mujoco as mj
from campaign import write, read, history
from closedfeed import axis,cached

def topoff(specfile,start,out,dt=.001,max_attempts=28,reject_limit=10,seed_offset=0):
    out.mkdir(parents=True,exist_ok=True)
    spec=read(specfile)
    for v in spec['parts'].values():v[0]=str((specfile.parent/v[0]).resolve())
    base=read(start/'fill.json');pose=np.load(start/'initial_pose.npz')
    loaded=base['loaded'];initial_n=loaded;n=loaded+max_attempts
    m=cached(spec,n,base['body_od'],base['friction'],dt);d=mj.MjData(m)
    nb=min(loaded, len(pose['active']));live=np.zeros(n,dtype=bool);live[:nb]=pose['active'][:nb]
    d.qpos[:1+7*loaded]=pose['qpos'][:1+7*loaded];d.qvel[:1+6*loaded]=pose['qvel'][:1+6*loaded]
    m0=float(d.qpos[0]);d.mocap_pos[0]=[0.,0.,400.]
    bids=np.array([m.body(f'p{i}').id for i in range(n)])
    q=np.array([m.jnt_qposadr[m.joint(f'f{i}').id] for i in range(n)])[:,None]+np.arange(7)
    vel=np.array([m.jnt_dofadr[m.joint(f'f{i}').id] for i in range(n)])[:,None]+np.arange(6)
    capids=np.asarray([m.geom('lid').id]+[m.geom(f'pilot{i}').id for i in range(32)])
    gids=np.asarray([m.geom(f'pill{i}').id for i in range(n)])
    for i in np.flatnonzero(live):m.body_gravcomp[bids[i]]=0.
    mj.mj_forward(m,d)
    seed=10000000+seed_offset+base['seed'];rng=np.random.default_rng(seed);rows=[];lid=float(spec['lid'])
    def heights():
        idx=np.flatnonzero(live);pos=d.qpos[q[idx]];u=axis(pos[:,3:]);sg=np.where(u[:,2]<0,-1,1)
        high=pos[:,:3]+u*sg[:,None]*(21.75-base['body_od'])/2
        high[:,2]+=base['body_od']/2
        sector=(np.floor((np.arctan2(high[:,1],high[:,0])+math.pi)*4/math.pi).astype(int)%8)
        z=np.array([np.max(high[sector==i,2]) if np.any(sector==i) else -np.inf for i in range(8)])
        return z,float(np.max(high[:,2]))
    def closure():
        d.mocap_pos[0]=[0.,0.,0.];mj.mj_forward(m,d)
        pair=np.isin(d.contact.geom[:,0],capids)|np.isin(d.contact.geom[:,1],capids)
        distances=d.contact.dist[pair];p=max(0.,-float(np.min(distances))) if len(distances) else 0.
        max_body=max((float(-c.dist) for c in d.contact if np.any(c.geom==m.geom('lid').id)),default=0.)
        d.mocap_pos[0]=[0.,0.,400.];mj.mj_forward(m,d)
        return p,max_body
    z,peak=heights();p0,_=closure();initial_gap=lid-peak;rejected=0;max_insert_overlap=0.;max_acc_pen=0.;accepted=0
    for a in range(max_attempts):
        if a and p0<=.08 and .0<=lid-peak<=1.5 and sum(np.isfinite(z))==8 and lid-np.median(z)<=12.0:break
        if rejected>=reject_limit:break
        before=(d.qpos.copy(),d.qvel.copy(),d.qacc_warmstart.copy(),d.time)
        if a%2:
            phi=rng.uniform(-math.pi,math.pi)
        else:
            sector=int(rng.choice(np.argsort(z)[:3]));phi=-math.pi+(sector+rng.uniform(.12,.88))*math.pi/4
        radius=np.sqrt(rng.uniform(0,1))*16.8
        quat=rng.standard_normal(4);quat/=np.linalg.norm(quat)
        i=loaded;d.qpos[q[i]]=np.r_[radius*math.cos(phi),radius*math.sin(phi),max(peak,lid)+15.,quat]
        live[i]=True;m.body_gravcomp[bids[i]]=0;d.qvel[vel[i]]=0;mj.mj_forward(m,d)
        newcontact=np.any(d.contact.geom==gids[i],axis=1)
        if np.any(newcontact):raise RuntimeError('Fresh capsule intersects initial packing')
        idx=np.flatnonzero(live);pen=0.;early_id=None
        for k in range(math.ceil(1.15/dt)):
            d.qpos[0]=m0;d.qvel[0]=0.;mj.mj_step(m,d)
            if d.ncon:pen=max(pen,-float(np.min(d.contact.dist)))
            fall=idx[d.xpos[bids[idx],2]<spec.get('floor',51.)-21.75/2-1]
            if len(fall):early_id=int(fall[0]);break
            if k*dt>.48 and k%40==0 and np.max(np.linalg.norm(d.qvel[vel[idx,:3]],axis=1))<6.:break
        z1,peak1=heights();p1,plane=closure()
        if early_id is not None:
            write(out/'uncommanded_drop.json',dict(attempt=a+1,id=early_id));raise RuntimeError('A capsule left with parked rotor during top-off')
        contacts_inside=not np.any(np.hypot(d.xpos[bids[idx],0],d.xpos[bids[idx],1])>30.05)
        fits=bool(lid>=peak1 and p1<=.08 and contacts_inside)
        rows.append(dict(attempt=a+1,accepted=fits,top_freeboard_mm=round(lid-peak1,4),closure_overlap_mm=round(p1,4),full_envelope_inside=contacts_inside,drop_radius_mm=round(radius,3),drop_azimuth_deg=round(math.degrees(phi),3),quaternion=quat.tolist(),settling_s=round(dt*(k+1),3),max_penetration_mm=round(pen,4)))
        if fits:
            loaded+=1;z,peak,p0=z1,peak1,p1;accepted+=1;rejected=0;max_acc_pen=max(pen,max_acc_pen)
        else:
            live[i]=False;m.body_gravcomp[bids[i]]=1.
            d.qpos[:],d.qvel[:],d.qacc_warmstart[:],d.time=before;mj.mj_forward(m,d)
            rejected+=1
        write(out/'topoff_attempts.json',rows)
        print('brim',out.parent.name,a+1,'accepted',fits,'active',loaded,'gap',round(lid-peak,2),'last trial tip gap',round(lid-peak1,2),'closure interference',round(p1,2),flush=True)
    assert p0<=.08 and lid-peak>=0
    work=dict(base);work.update(loaded=loaded,retained_at_start=int(sum(live)),first_motion_zmax=round(peak,4),lid_freeboard_mm=round(lid-peak,4),top_by_angular_sector_mm=[round(float(v),3) if np.isfinite(v) else None for v in z],median_sector_freeboard_mm=round(lid-float(np.median(z[np.isfinite(z)])),4),occupied_sectors=int(sum(np.isfinite(z))),source_start_loaded=initial_n,source_start_gap_mm=round(initial_gap,4),topoff_rng_seed=seed,accepted_topoff=accepted,rejected_topoff=len(rows)-accepted,shut_lid_max_interference_mm=round(p0,4),max_topoff_penetration_accepted_mm=round(max_acc_pen,4),fill_mode='base full loose pour, independently gravity top-off with snapped-lid approach clearance check',dt=dt)
    work.pop('at_start_upright_within_15deg',None);work.pop('mean_pill_center_z',None)
    write(out/'fill.json',work);write(out/'events.json',read(start/'events.json'));write(out/'stages.json',read(start/'stages.json'))
    np.savez_compressed(out/'initial_pose.npz',qpos=d.qpos.copy(),qvel=d.qvel.copy(),active=live.copy())
    print('BRIM',out,loaded,work['lid_freeboard_mm'],work['median_sector_freeboard_mm'],p0,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('spec',type=Path);p.add_argument('base_fill',type=Path);p.add_argument('inertia',type=Path);p.add_argument('out',type=Path);p.add_argument('--attempts',type=int,default=28);p.add_argument('--dt',type=float,default=.0005);p.add_argument('--cycles',type=int,default=6);a=p.parse_args()
    topoff(a.spec.resolve(),a.base_fill,a.out/'fill',max_attempts=a.attempts);history(a.spec,a.out/'fill',a.inertia,a.out/'motor',dt=a.dt,cycles=a.cycles)
