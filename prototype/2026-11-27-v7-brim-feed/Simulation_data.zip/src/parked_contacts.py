"""Optional geometric contact-distance snapshot of the full pack with its lid seated."""
from pathlib import Path
import json, numpy as np, mujoco as mj, argparse
from closedfeed import cached
from audit_helpers import details
def inspect(spec_path,start,dt=.0005):
    spec=json.loads(spec_path.read_text())
    for v in spec['parts'].values():v[0]=str((spec_path.parent/v[0]).resolve())
    pack=json.loads((start/'fill.json').read_text());u=np.load(start/'initial_pose.npz');m=cached(spec,pack['loaded'],pack['body_od'],pack['friction'],dt);d=mj.MjData(m)
    d.qpos[:]=u['qpos'][:m.nq];d.qvel[:]=u['qvel'][:m.nv];d.mocap_pos[0]=[0.,0.,0.];mj.mj_forward(m,d)
    ids=np.argsort(d.contact.dist)[:6]
    return dict(loaded=pack['loaded'],contacts=d.ncon,largest_negative_geometric_mesh_or_capsule_distances=[details(m,d.contact[int(i)]) for i in ids],dimensions='mm, closed lid, before applying motor torque; duplicated triangles may refer to the same contact location')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('spec',type=Path);p.add_argument('fill',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
    val=inspect(a.spec,a.fill);a.out.write_text(json.dumps(val,indent=2));print(val)
