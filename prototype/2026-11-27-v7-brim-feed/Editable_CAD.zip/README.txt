Three fixed end-drop galleries for a V7 canister. Native CAD uses millimeters, the V7 deck top is z=0.

Python 3.12 (CadQuery 2.8.0 and numpy)
    python -m pip install cadquery==2.8.0
    python enddrop/end_drop_feed.py
    python enddrop/end_drop_feed.py contact
    python enddrop/passages.py

The first command generates a STEP assembly and 13 bed-oriented STL files under enddrop/release. The second generates all seven installed collision surfaces, their frames and the shaft moment of inertia. The third measures the as-built clearances and the passage of the measured 21.75 × Ø7.75 capsule along each vertical tube axis.

The guide selects three tangential feed lanes at -150°, -30° and +90°. The asymmetric trough retains an outer bank after the inner bank falls away. The single guide is stationary and includes its own cutoff, key, and clamped rim. Fit and bolt the revised lower wheel first; lower the guide over it, engaging the collar key, and capture the rim with the ordinary V7 bayonet hopper. The original clearance pocket under the fixed guide allows the recessed M3 head to rotate freely. The existing captive bulk relief roof is independent of this part.

Compared with the previous pinned vertical-head cartridge print the new Stationary_end_drop_guide and Pocket_metering_rotor. The previous rotating upper feeder and its separate fixed cutoff plate are removed. When upgrading directly from the stationary five-way trial, only Stationary_end_drop_guide changes.
