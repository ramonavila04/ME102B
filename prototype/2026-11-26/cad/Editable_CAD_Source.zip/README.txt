Serviceable canister and three-piece deck | CAD source

The assembly is designed for a 7.75 mm diameter × 21.75 mm long cylindrical test piece. Dimensions are in mm. The reference plane is the top of the deck, Z = 0. Local +Y points outward from the dispenser axis. The station centers lie on a 96 mm radius.

Use Python 3.12 and CadQuery 2.8. Put the original named Pill_Dispenser_V7_Heat_Inserts.step beside the source, or supply its path. Run the following commands in this folder.

  python -m pip install -r requirements.txt
  python build_retrofit.py --v7 "/path/to/Pill_Dispenser_V7_Heat_Inserts.step" --out build

The script creates Single_Canister.step, Six_Canister_Dispenser.step and Print_Parts.zip. STL quantity suffixes are for one complete six-station appliance. Print one of each file in One_of_each_per_canister for a single test station. Print three identical Deck_sector_120deg pieces for the shared deck. The angles embedded in the exported STL files are the intended build orientations.

head26.py defines the upright magazine, rotor, stationary plate and lid. drive26.py defines the saddle, bearing stack and reused shaft, coupler and motor interfaces. guide26.py defines the discharge path. gravity_release.py sets up the capsule and coordinate transforms. deck.py defines the three deck pieces and mounting interface.

Changing the article dimensions, release location or angle can require coordinated changes in the rotor, plate, guide and shared deck. Recheck the entire discharge path and neighboring cartridge clearances after editing those dimensions.
