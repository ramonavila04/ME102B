"""Bounded closed-lid V7 original-bulk trial starting from the unmodified global step-12 checkpoint."""
import argparse, importlib, json, math, shutil, sys
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser();p.add_argument('--code',type=Path,required=True);p.add_argument('--first',type=Path,required=True);p.add_argument('--second',type=Path,required=True);p.add_argument('--spec',type=Path,required=True);p.add_argument('--inertia',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();sys.path.insert(0,str(a.code.resolve()));sim=importlib.import_module('campaign');read=lambda f: json.loads(f.read_text()); prior=[read(f/'motor/results.json') for f in (a.first,a.second)];n=prior[0]['loaded'];assert n==77 and all(len(r['steps'])==6 and all(s['completed'] and s['valid_drops']==1 and s['offpath']==0 for s in r['steps']) for r in prior);assert prior[1]['dt_s']==.00025 and all(r['cap_Nm']==.1 for r in prior);assert prior[1]['inputs']==prior[0]['inputs']
initial=np.load(a.first/'fill/initial_pose.npz');oldpos=initial['qpos'][1:1+7*n].reshape(n,7);vz=np.abs(1-2*(oldpos[:,4]**2+oldpos[:,5]**2));oldlow=oldpos[:,2]-3.875-7*vz;upper=set(map(int,np.flatnonzero((oldlow>116.8)&initial['active'][:n])));assert len(upper)==38
full_ids=[e['id'] for r in prior for s in r['steps'] for e in s['events']];assert len(full_ids)==12 and len(set(full_ids))==12 and not upper.intersection(full_ids)
src=a.second/'motor/after_6.npz';turn=np.load(src);assert set(np.flatnonzero(~turn['active'][:n]))==set(full_ids);offset=math.degrees(turn['qpos'][0]-initial['qpos'][0]);a.out.mkdir(parents=True,exist_ok=True);start=a.out/'start';start.mkdir(exist_ok=True);assert not (a.out/'motor/results.json').exists(),'Choose a new replay directory';shutil.copyfile(src,start/'initial_pose.npz');shutil.copyfile(a.first/'fill/fill.json',start/'fill.json');restart={'parent_global_index':12,'source_pose_sha256':sim.sha(src),'original_pour_sha256':sim.sha(a.first/'fill/initial_pose.npz'),'second_global_index_6_sha256':sim.sha(a.first/'motor/after_6.npz'),'past_ids':full_ids,'remaining_at_start':int(turn['active'][:n].sum()),'original_loaded':n,'original_strict_upper_ids':sorted(upper),'global_home_offset_deg':offset,'cap_Nm':.1,'dt_s':.00025,'original_fill_seed':prior[0]['seed'],'original_friction':prior[0]['friction'],'mechanical_state':'All recorded shaft/capsule poses, velocities and live flags carried forward. Closed lid; no manual changes to capsule layout.','numerical_state':'PI error integral, rate ramp, warmstart and time are reset at block boundary following the final completed dwell. Unchanged through this bounded sequence.'};sim.write(a.out/'restart.json',restart)
class StopAtCheckpoint(Exception):pass
save=np.savez_compressed;reason=None
def checkpoint(path,*args,**kwargs):
 global reason
 save(path,*args,**kwargs)
 if Path(path).parent!=a.out/'motor':return
 s=read(a.out/'motor/results.json')['steps'][-1]
 if s['stall']:reason='sustained motor stall'
 elif s['timeout']:reason='drive timeout'
 elif not s['completed']:reason='position or settle check failed'
 elif s['offpath']:reason='off-path crossing'
 elif s['valid_drops']==0:reason='empty completed index'
 elif s['valid_drops']>1:reason='multiple releases on a completed index'
 elif any(e['valid_outlet'] and e['id'] in upper for e in s['events']):reason='original wholly-above-crown capsule reached intended outlet'
 elif s['step']==6:reason='six bounded commands reached with only non-bulk-origin capsules released'
 print('Global index',s['step']+12,'completed',s['completed'],'drops',s['valid_drops'],'torque',s['peak_motor_torque_Nm'],'IDs',[e['id'] for e in s['events']],'stop',reason,flush=True)
 if reason:raise StopAtCheckpoint
np.savez_compressed=checkpoint
try:sim.history(a.spec,start,a.inertia,a.out/'motor',limit=.1,dt=.00025,cycles=6)
except StopAtCheckpoint:pass
finally:np.savez_compressed=save
r=read(a.out/'motor/results.json');assert r['inputs']==prior[0]['inputs'] and r['mass_model']==prior[0]['mass_model'] and r['friction']==prior[0]['friction'] and r['pose_sha256']==sim.sha(src)
rows=[]
for s in r['steps']:
 events=[dict(capsule=e['id'],from_original_strict_bulk=e['id'] in upper,initial_bottom_tip_mm=float(oldlow[e['id']]),initial_center_z_mm=float(oldpos[e['id'],2]),intended=e['valid_outlet'],degree_within_index=e['index_degrees'],degree_from_first_home=round(offset+e['world_degrees'],5),local_block_seconds=e['time_s']) for e in s['events']];rows.append(dict(global_index=s['step']+12,completed=s['completed'],stall=s['stall'],timeout=s['timeout'],intended_drops=s['valid_drops'],offpath=s['offpath'],remaining=s['remaining'],end_deg_from_original_home=round(offset+s['end_deg'],5),peak_tau_Nm=s['peak_motor_torque_Nm'],events=events))
assert not set(full_ids).intersection(e['capsule'] for s in rows for e in s['events']);sim.write(a.out/'summary.json',{'stop_reason':reason,'checks_at_each_completed_physical_index':True,'global_index_limit':18,'strict_original_bulk_height_mm':116.8,'rows':rows,'restart':restart});print('STOP',reason,flush=True)
