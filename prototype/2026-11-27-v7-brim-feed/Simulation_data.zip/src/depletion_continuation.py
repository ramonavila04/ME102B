"""After successful sustained full-canister test, resume its exact cold-pour bodies until depleted or a discrepancy."""
import argparse
import shutil
from pathlib import Path
import numpy as np
from campaign_bounded import history,read,write,sha


def main():
    p=argparse.ArgumentParser()
    for k in ('spec','inertia','first','out'):p.add_argument(k,type=Path)
    a=p.parse_args()
    if (a.out/'motor/results.json').exists():raise RuntimeError('Choose a fresh continuation directory.')
    previous=read(a.first/'summary.json');protocol=read(a.first/'protocol.json');res=read(a.first/'motor/results.json')
    assert previous['stop']=='original-bulk delivery and target clean sequence demonstrated'
    offset=previous['attempted']; assert len(res['steps'])==offset
    assert all(s['completed'] and s['offpath']==0 and s['valid_drops']==1 for s in res['steps'])
    assert res['early_drops']==0 and previous['original_strict_bulk_delivered']
    original=read(a.first/'fill/fill.json')
    assert original['seed']==protocol['seed'] and original['friction']==protocol['friction']
    first_live=a.first/'fill/initial_pose.npz';last_state=a.first/f'motor/after_{offset}.npz'
    with np.load(first_live) as cold,np.load(last_state) as last:
        cumulative_start=float(np.degrees(last['qpos'][0]-cold['qpos'][0]))
        n=original['loaded'];remaining=int(np.sum(last['active'][:n]));assert remaining==n-offset
        original_q=cold['qpos'][1:1+7*n].reshape(n,7).copy()
    bulk=set(protocol['strict_bulk_ids']);start=a.out/'start';start.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(a.first/'fill/fill.json',start/'fill.json')
    shutil.copyfile(last_state,start/'initial_pose.npz')
    prior_ids=[e['id'] for s in res['steps'] for e in s['events']];assert len(set(prior_ids))==offset
    restart=dict(cold_fill_seed=original['seed'],cold_fill_count=n,prior_indices=offset,prior_intended_exit_ids=prior_ids,
        remaining_at_start=remaining,global_home_offset_deg=cumulative_start,current_dt_s=res['dt_s'],
        maximum_drive_torque_Nm=res['cap_Nm'],terrain_hashes=res['inputs'],
        original_pose_sha256=sha(first_live),continuation_pose_sha256=sha(start/'initial_pose.npz'),
        previous_results_sha256=sha(a.first/'motor/results.json'),
        note='Shaft/capsule positions, orientations and velocities and all remaining identities are restored exactly. One reset of controller rate ramp and integral, contact warm starts and solver clock at the parked block boundary. No refill or reorientation, with all controllers and dynamic state continuous after this one restart.',
        stop_rule='End after first unsatisfied motion, zero/extra release, any off-path crossing, or last original capsule leaving in a completed single. Do not force motion after a failure.')
    write(a.out/'restart.json',restart)
    records=[];new_identity=set()
    def record(row):
        k=offset+row['step']; events=[]
        for e in row['events']:
            i=e['id'];assert i not in prior_ids and i not in new_identity;new_identity.add(i)
            events.append(dict(capsule_id=i,strict_initial_bulk=i in bulk,initial_center_z_mm=round(float(original_q[i,2]),3),
                valid_outlet=e['valid_outlet'],drop_world_from_original_home_deg=round(cumulative_start+e['world_degrees'],4)))
        if not row['completed']: reason='stall' if row['stall'] else 'motion failed to settle'
        elif row['offpath']:reason='off-path escape'
        elif row['valid_drops']==0:reason='miss'
        elif row['valid_drops']!=1:reason='multiple releases'
        elif row['remaining']==0:reason='entire original loose pour emptied in exactly one capsule per completed index'
        else:reason=''
        records.append(dict(global_index=k,completed=row['completed'],end_angle_from_home_deg=round(cumulative_start+row['end_deg'],5),
            valid_drops=row['valid_drops'],offpath=row['offpath'],events=events,remaining=row['remaining'],
            peak_torque_Nm=row['peak_motor_torque_Nm'],peak_penetration_mm=row['peak_penetration_mm']))
        write(a.out/'summary.json',dict(initially_loaded=n,clean_commands_before_restart=offset,rows=records,stop=reason))
        return bool(reason)
    print('CONTINUATION',restart,flush=True)
    outcome=history(a.spec.resolve(),start,a.inertia.resolve(),a.out/'motor',limit=res['cap_Nm'],dt=res['dt_s'],cycles=remaining,stop_on=record)
    if len(records)!=len(outcome['steps']):record(outcome['steps'][-1])
    assert outcome['inputs']==res['inputs'] and outcome['mass_model']==res['mass_model']
    print('FINAL',read(a.out/'summary.json')['stop'],flush=True)


if __name__=='__main__': main()
