"""Build the upper guide's STL from the BRep exactly on the build plane.
Weld coincident tessellation endpoints to 0.00001 mm and remove resulting zero-area faces.
The native solid and physics BRep are not modified by this manufacturing-mesh correction.
"""
from pathlib import Path
import struct
import numpy as np
import cadquery as cq
from OCP.BRepTools import BRepTools
from zipfile import ZipFile,ZIP_DEFLATED
def finish(out):
    out=Path(out);filename='Stationary_end_drop_guide.stl'
    solid=cq.Shape.importBrep(str(out/'brep/Stationary_end_drop_guide.brep')).translate((0,0,-73.65))
    BRepTools.Clean_s(solid.wrapped)
    stl=out/'stl'/filename;solid.exportStl(str(stl),tolerance=.045,angularTolerance=.12,parallel=False)
    data=stl.read_bytes()
    dtype=np.dtype([('normal','<f4',3),('vertex','<f4',(3,3)),('attr','<u2')])
    orig=np.frombuffer(data,dtype=dtype,offset=84)
    pts,ix=np.unique(np.round(orig['vertex'].astype(float).reshape(-1,3),5),axis=0,return_inverse=True)
    tris=ix.reshape(-1,3);tri=pts[tris]
    normals=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
    area=np.linalg.norm(normals,axis=1);keep=area>1.e-10
    # At three tangent trim seams OCC emits two coincident, oppositely wound triangles.
    # Both are zero-net boundary sheets. Confirm opposite orientation before dropping the pair.
    distinct, group, counts = np.unique(np.sort(tris,axis=1),axis=0,return_inverse=True,return_counts=True)
    for index in np.where(counts == 2)[0]:
        pair=np.where(group==index)[0]
        if keep[pair].all() and np.dot(normals[pair[0]], normals[pair[1]]) < -.999999 * area[pair].prod():
            keep[pair]=False
    rec=np.zeros(np.sum(keep),dtype=dtype);rec['vertex']=tri[keep];rec['normal']=normals[keep]/area[keep,None]
    q=tris[keep];e=np.sort(np.vstack([q[:,[0,1]],q[:,[1,2]],q[:,[0,2]]]),axis=1)
    _,edges=np.unique(e,axis=0,return_counts=True);assert np.all(edges==2),(np.unique(edges,return_counts=True))
    with open(stl,'wb')as f:
        f.write(b'V7 stationary end-drop guide - print mesh; millimeters'.ljust(80,b' '));f.write(struct.pack('<I',len(rec)));f.write(rec.tobytes())
    with ZipFile(out/'V7_Vertical_Queue_Print_Parts.zip','w',ZIP_DEFLATED)as z:
        for f in sorted((out/'stl').glob('*.stl')):z.write(f,f.name)
    return len(orig),len(rec)
if __name__=='__main__':
    import sys
    for d in sys.argv[1:]:print(d,finish(d))
