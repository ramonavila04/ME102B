"""Gravity-pour identical seeded, randomly oriented capsules, then index the actual CAD."""
from pathlib import Path
import argparse, csv, json, math, os, time
import numpy as np
import mujoco as mj
from rigidfeed import axis, cached

L=21.75
def run(spec_file,out,seed=750,mu=.32,od=7.75,dt=.0015,state='full',cycles=6,trace=False, speed=18.,warm=0,allow_preliminary=False):
 out=Path(out);out.mkdir(exist_ok=True,parents=True)
 path=Path(spec_file).resolve();spec=json.loads(path.read_text())
 for name,(f,domain) in list(spec['parts'].items()):
  spec['parts'][name]=[str((path.parent/f).resolve()),domain]
 lid=float(spec['lid']);floor=float(spec.get('floor',51));outlet=np.asarray(spec.get('ports',[[0,-15.6]])[0])
 n=140 if state=='full' else int(state)
 capacity=n
 m=cached(spec,n,od,mu,dt);d=mj.MjData(m);rng=np.random.default_rng(seed)
 bids=np.asarray([m.body(f'p{i}').id for i in range(n)])
 qids=np.array([m.jnt_qposadr[m.joint(f'f{i}').id] for i in range(n)])[:,None]+np.arange(7)
 vids=np.array([m.jnt_dofadr[m.joint(f'f{i}').id] for i in range(n)])[:,None]+np.arange(6)
 first_seated={}; first_throat={}; live=np.zeros(n,dtype=bool);loaded=0;theta=0.;inc=0;events=[];snapshots=[];tic=time.monotonic()
 init=0.;next_snap=0.;row_list=[]
 def tops():
  idx=np.flatnonzero(live)
  if not len(idx):return np.empty(0)
  return d.xpos[bids[idx],2]+np.abs(axis(d.qpos[qids[idx]][:,3:])[:,2])*(L-od)/2+od/2
 def snapshot(phase,num):
  nonlocal next_snap
  if not trace or d.time<next_snap:return
  next_snap=d.time+(0.22 if phase=='fill' else .11)
  ids=np.flatnonzero(live);poses=d.qpos[qids[ids]]
  snapshots.append(dict(t=round(float(d.time),5),phase=phase,index=num,angle=round(math.degrees(theta),4),ids=ids.tolist(),xyz=poses[:,:3].round(3).tolist(),axis=axis(poses[:,3:]).round(4).tolist(),released=[int(e['id']) for e in events if e['valid_xy']]))
 def stage(sec,rate,phase,num):
  nonlocal theta,inc
  steps=int(math.ceil(sec/dt));step_theta=math.radians(rate*sec/steps)
  peak=0.;tau=0.; torque_values=[]; first=len(events);minpos=1e5;start=int(np.sum(live));entered={}
  for k in range(steps):
   inc+=1
   d.qpos[0]=theta;d.qvel[0]=step_theta/dt;theta+=step_theta
   mj.mj_step(m,d);idx=np.flatnonzero(live)
   # Force readings correspond to the driven angular coordinate in g mm² / s²; 1e-9 N·m.
   if d.ncon:peak=max(peak,float(-np.min(d.contact.dist)))
   force=abs(float(d.qfrc_constraint[0]))*1e-9; tau=max(tau,force);torque_values.append(force)
   z=d.xpos[bids[idx],2]
   for store, gate in ((first_seated,floor+L/2+1.),(first_throat,spec.get('vertical_tube_measure_z',floor+L/2+1.))):
    for i in idx[z<gate]:
     i=int(i)
     if i not in store:
      u=axis(d.qpos[qids[i,3:]][None,:])[0];store[i]=dict(index=num,phase=phase,t=round(float(d.time),3),tilt_deg=round(math.degrees(math.acos(np.clip(abs(u[2]),0,1))),3))
   for i in idx[z<floor-L/2-1.0]:
    x,y,zc=d.xpos[bids[i]];a=axis(d.qpos[qids[i,3:]][None,:])[0];xy=np.array([x,y])-outlet
    valid=bool(np.hypot(max(abs(xy[0])-8,0.),xy[1])<=7.0)
    ev=dict(phase=phase,index=num,id=int(i),time=round(float(d.time),5),x=round(float(x),3),y=round(float(y),3),z=round(float(zc),3),valid_xy=valid,tilt_deg=round(math.degrees(math.acos(np.clip(abs(a[2]),0,1))),3),angle_deg=round(math.degrees(theta),3))
    events.append(ev);live[i]=False;m.body_gravcomp[bids[i]]=1.
    d.qpos[qids[i,:3]]=[500+30*i,300,100];d.qvel[vids[i]]=0.
   snapshot(phase,num)
  subset=events[first:];count=sum(e['valid_xy'] for e in subset);esc=len(subset)-count
  return dict(phase=phase,index=num,start=start,remaining=int(np.sum(live)),drops=count,offpath=esc,
      max_penetration_mm=round(peak,4),contact_torque_peak_Nm=round(tau,5),contact_torque_p95_Nm=round(float(np.percentile(torque_values,95)),5),exit_tilts_deg=[e['tilt_deg'] for e in subset if e['valid_xy']])
 def put(ks):
  nonlocal loaded,init
  # The group uses a triangle of radius 15.8 mm just above the physical lip; its widest footprint stays within the 59.7 mm inlet.
  phi=rng.uniform(0,math.tau); zbase=max(spec.get("highest_feed",lid-8),max(tops(),default=0.))+14.
  for k in range(ks):
   i=loaded;p=phi+k*2*math.pi/3;rho=rng.uniform(13.5,16.8)
   x,y=rho*math.cos(p),rho*math.sin(p)
   q=rng.standard_normal(4);q/=np.linalg.norm(q)
   d.qpos[qids[i]]=np.r_[x,y,zbase+rng.uniform(0,2),q];d.qvel[vids[i]]=0.;m.body_gravcomp[bids[i]]=0.;live[i]=True;loaded+=1
  mj.mj_forward(m,d)
  # Verify no newly created body intersects any other body or CAD surface at insertion.
  if d.ncon:
   gids=set([g for i in range(loaded-ks,loaded) for g in (m.geom(f'pill{i}').id,m.geom(f'seam{i}').id)])
   cols=d.contact.geom
   sel=np.isin(cols[:,0],list(gids))|np.isin(cols[:,1],list(gids))
   if np.any(sel):init=max(init,-float(min(d.contact.dist[sel])))
  if init>.10:raise RuntimeError(f'unsupported pour placement, {init} mm initial penetration')
 def dataout(key,data):
  (out/f'{key}.json').write_text(json.dumps(data,indent=None if key=='trajectory' else 2))
 def dump():
  dataout('stages',row_list);dataout('events',events);dataout('orientation',{'metering_cup':first_seated,'queue_entry':first_throat})
  if snapshots:dataout('trajectory',snapshots)
 # Full corresponding to settled pile reaching the underside of the lid with 1–7mm vertical freeboard.
 # Save last lid-clear retained batch; if geometrically overfull, rewind it and add single capsules.
 lastlog=0;single_mode=False
 while loaded<n:
  tip=tops();peak=float(max(tip)) if len(tip) else floor
  if state=='full' and loaded>=40 and peak>=lid-7 and peak<=lid-.35:break
  if state=='full' and loaded>=40 and peak>lid-.35:
   # Overflow batch was rejected from this settled initial condition.
   if saved is None:raise RuntimeError('overflow first batch')
   d.qpos[:],d.qvel[:],d.qacc_warmstart[:],d.time,live[:],loaded,m.body_gravcomp[:],ns,no,ne,rstate,next_snap=saved
   snapshots=snapshots[:ns];row_list=row_list[:no];events=events[:ne];rng.bit_generator.state=rstate
   mj.mj_forward(m,d)
   if single_mode:break
   single_mode=True;continue
  elevated=(state=='full' and peak>lid-17 and loaded>=24)
  ks=min(n-loaded,1 if elevated or single_mode else 3)
  saved=(d.qpos.copy(),d.qvel.copy(),d.qacc_warmstart.copy(),float(d.time),live.copy(),loaded,m.body_gravcomp.copy(),len(snapshots),len(row_list),len(events),rng.bit_generator.state,next_snap)
  put(ks)
  row_list.append(stage(.31 if ks==3 else .42,0,'fill',0))
  # The freeboard metric must use a settled pile. High flying pieces are failures, not a full hopper.
  for extra in range(5):
   ids0=np.flatnonzero(live)
   if not len(ids0) or np.max(np.linalg.norm(d.qvel[vids[ids0,:3]],axis=1))<35:break
   row_list.append(stage(.15,0,'settle_pour',0))
  if loaded-lastlog>=15:
   print('gravity pour',loaded,'top',round(max(tops()),2),'elapsed',round(time.monotonic()-tic,1),flush=True);lastlog=loaded
 if state=='full' and loaded==n:raise RuntimeError('allocated simulation count exhausted before reaching lid')
 row_list.append(stage(.55,0,'settle',0))
 top=tops();ids=np.flatnonzero(live);pos=d.qpos[qids[ids]];qtop=pos[:,:3].copy();dirs=axis(pos[:,3:]);sg=np.where(dirs[:,2]<0,-1.,1.)
 qtop+=dirs*sg[:,None]*(L-od)/2;qtop[:,2]+=od/2
 octant=np.floor((np.arctan2(qtop[:,1],qtop[:,0])+np.pi)*4/np.pi).astype(int)%8
 qheight=[round(float(max(top[octant==ii])),3) if np.any(octant==ii) else None for ii in range(8)]
 free=lid-max(top)
 if state=='full' and not allow_preliminary and (loaded<40 or free>12. or len([h for h in qheight if h is not None])<7 or lid-float(np.median([h for h in qheight if h is not None]))>24.):raise RuntimeError(f'Failed full check: {loaded}, freeboard {free}, top sectors {qheight}')
 if free<0:raise RuntimeError(f'capsule crosses lid by {-free} mm')
 if any(not e['valid_xy'] for e in events):raise RuntimeError(f'Off-axis crossing while filling {events}');
 m.geom_contype[m.geom('lid').id]=1;m.geom_conaffinity[m.geom('lid').id]=2
 fill=dict(seed=seed,friction=mu,body_od=od,dt=dt,speed_deg_per_s=speed,lid_z=lid,fill_mode=state,loaded=loaded,retained_at_start=int(np.sum(live)),first_motion_zmax=round(float(max(top)),3),lid_freeboard_mm=round(float(free),3),top_by_angular_sector_mm=qheight,median_sector_freeboard_mm=round(lid-float(np.median([h for h in qheight if h is not None])),3),mean_pill_center_z=round(float(pos[:,2].mean()),3),insertion_overlap_max=round(init,5),at_start_upright_within_15deg=int(sum(abs(dirs[:,2])>math.cos(math.radians(15)))),early_drops=sum(e['valid_xy'] for e in events),max_fill_penetration_mm=max(r['max_penetration_mm'] for r in row_list))
 np.savez_compressed(out/'initial_pose.npz',qpos=d.qpos,qvel=d.qvel,time=d.time,active=live,body_gravcomp=m.body_gravcomp);dataout('fill',fill);dump();print('START',fill,flush=True)
 for k in range(1,cycles+1):
  if not np.any(live):break
  a=stage(60/speed,speed,'index',k);b=stage(.55,0,'dwell',k)
  row_list.extend([a,b]);dump()
  print('index',k,'drops',a['drops']+b['drops'],'overlap',max(a['max_penetration_mm'],b['max_penetration_mm']),'elapsed',round(time.monotonic()-tic,1),flush=True)
 if int(np.sum(live))+len(events)!=loaded:raise RuntimeError('material balance')
 dataout('done',dict(elapsed_s=round(time.monotonic()-tic,2),n_steps=inc,stepsize=dt,capsules_at_end=int(np.sum(live))));return row_list

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('spec');p.add_argument('out');p.add_argument('--seed',type=int,default=750);p.add_argument('--mu',type=float,default=.32);p.add_argument('--dt',type=float,default=.0015);p.add_argument('--state',default='full');p.add_argument('--cycles',type=int,default=6);p.add_argument('--speed',type=float,default=18.);p.add_argument('--trace',action='store_true')
 a=p.parse_args();run(a.spec,a.out,seed=a.seed,mu=a.mu,dt=a.dt,state=a.state,cycles=a.cycles,trace=a.trace,speed=a.speed)
