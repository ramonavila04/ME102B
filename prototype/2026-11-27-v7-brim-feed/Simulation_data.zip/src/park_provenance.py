"""Track the original bulk stock and actual axial neighbors of the next cup, using saved poses only."""
import sys,json,math
from pathlib import Path
import numpy as np
from closedfeed import axis

def catalogue(fill, motor, crown):
    with np.load(fill/'initial_pose.npz') as cold:
        n=int(np.sum(cold['active']))
        orig=cold['qpos'][1:1+n*7].reshape(n,7).copy()
    orig_tip=orig[:,2]-7*np.abs(axis(orig[:,3:])[:,2])-3.875
    bulk=np.flatnonzero(orig_tip>crown)
    rows=[]
    files=[(0,fill/'initial_pose.npz')]
    files += sorted(((int(p.stem.split('_')[1]),p) for p in motor.glob('after_*.npz')),key=lambda t:t[0])
    for step,fp in files:
        with np.load(fp) as f:
            live=np.flatnonzero(f['active'][:n]);q=f['qpos'][1:1+7*n].reshape(n,7);theta=float(f['qpos'][0])
            by_id=axis(q[:,3:]);tip=q[:,2]-7*np.abs(by_id[:,2])-3.875
            strict=np.intersect1d(bulk,live)
            donor=min([int(i) for i in strict],key=lambda i:tip[i]) if strict.size else None
            # For each material pocket centered at r=15.6, find its center in current world coordinates.
            frame=np.radians(-90+60*np.arange(6))+theta
            pocket=np.column_stack((np.cos(frame),np.sin(frame)))*15.6
            # Feed index is positive about z. The cup currently at -150 degrees meets outlet at -90 next.
            incoming=int(np.argmin(np.sum((pocket-15.6*np.array([math.cos(math.radians(-150)),math.sin(math.radians(-150))]))**2,axis=1)))
            delta=np.linalg.norm(q[live,None,:2]-pocket[None,:,:],axis=2)
            def details(i,dist):
                return dict(id=i,center_z_mm=round(float(q[i,2]),3),r_from_pocket_mm=round(float(dist),3),
                            tilt_from_vertical_deg=round(math.degrees(math.acos(np.clip(abs(by_id[i,2]),0.,1.))),3),
                            low_tip_z_mm=round(float(tip[i]),3),original_bulk=bool(orig_tip[i]>crown))
            cells=[]
            for j in range(6):
                close=np.flatnonzero((delta[:,j]<4.25)&(q[live,2]<120))
                all_near=[details(int(live[k]),delta[k,j]) for k in close]
                cells.append(sorted(all_near,key=lambda c:c['center_z_mm']))
            rows.append(dict(after_index=step,remaining=len(live),material_cell_due_next=incoming,
                material_cells_with_a_center_below_z70=sum(any(k['center_z_mm']<70 for k in col) for col in cells),
                adjacent_capsules_by_material_cell=cells,incoming_lowest=(cells[incoming][0] if cells[incoming] else None),
                strictly_above_stock_remaining=len(strict),
                lowest_tip_of_original_bulk=None if donor is None else details(donor,delta[np.flatnonzero(live==donor)[0],:].min())))
    return dict(crown_z=crown, initially_fully_above_crown=bulk.tolist(),cup_axis_radius_mm=15.6,
        nearby_center_r_cutoff_mm=4.25,nearby_center_z_cutoff_mm=120,
        qualification='Geometric neighborhoods from saved states only. Multiple listed neighbors may partly occupy stages rather than separate metering pockets. Only measured unique outlet crossings count as delivered capsules.',parks=rows)

if __name__=='__main__':
    base=Path(sys.argv[1]);crown=float(sys.argv[2])
    print(json.dumps(catalogue(base/'fill',base/'motor',crown),indent=2))
