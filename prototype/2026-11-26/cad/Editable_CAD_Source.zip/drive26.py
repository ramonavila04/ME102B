"""Direct motor/shaft saddle and top-access M3 attachment for one removable cartridge.
Coordinates in mm: x tangential, y radially outward, z=0 at deck top.
"""
from pathlib import Path
from functools import lru_cache
from math import sqrt, hypot, degrees, radians, cos, sin, atan2
import os
import cadquery as cq

MOUNT=[(-32.,33.),(32.,33.)]
STATOR_PADS=[(-16.,-30.),(16.,-10.),(0.,16.)]
REF_NAMES=['Drive_shaft','Shaft_coupler','Pololu_gearmotor','Motor_face_screw_A','Motor_face_screw_B']
ERROR=1e-5

def tilt(s):
    return s.rotate((0,0,0),(1,0,0),50).rotate((0,0,0),(0,0,1),180).translate((0,0,95))

def flatten(s):
    return s.translate((0,0,-95)).rotate((0,0,0),(0,0,1),-180).rotate((0,0,0),(1,0,0),-50)

def cylinder(r,z0,z1,x=0,y=0):
    return cq.Solid.makeCylinder(r,z1-z0,(x,y,z0))

def ring(ro,ri,z0,z1):
    return cylinder(ro,z0,z1).cut(cylinder(ri,z0-.05,z1+.05))

def rounded_rectangle(w,d,x,y,z,r):
    face=cq.Face.makeFromWires(cq.Workplane('XY',origin=(x,y,z)).rect(w,d).val())
    return face.fillet2D(r,face.Vertices()).outerWire()

def insert(x,y,z):
    return ring(2.50,1.51,z-4,z).translate((x,y,0))

def insert_pilot(x,y,z):
    return cylinder(2.30,z-5.6,z+.02,x,y).fuse(
        cq.Solid.makeCone(2.30,2.67,.37,(x,y,z-.37)))

def deck_screw(x,y):
    # M3 x 8 ISO 4762, with a 1.75 mm-deep head counterbore in the 5 mm foot.
    hexhole=cq.Workplane('XY',origin=(x,y,4.85)).polygon(6,2.50*2/sqrt(3)).extrude(1.6).val()
    return cylinder(1.48,-4.75,3.25,x,y).fuse(cylinder(2.75,3.25,6.25,x,y)).cut(hexhole).clean()

def filleted_bar(x0,y0,x1,y1,r,z0,z1):
    length=hypot(x1-x0,y1-y0)
    return (cq.Workplane('XY',origin=((x0+x1)/2,(y0+y1)/2,z0))
            .slot2D(length+2*r,2*r,degrees(atan2(y1-y0,x1-x0)))
            .extrude(z1-z0).val())

def bearing(z0):
    return ring(7.9375,6.60,z0,z0+4.98).fuse(
        ring(6.62,4.69,z0+.18,z0+4.80),ring(4.71,3.175,z0,z0+4.98)).clean()

def hardware_shapes():
    local=Path(__file__).parent/'hardware'
    ref=Path(os.environ.get('PILL_MOTOR_ASSETS',str(local)))
    if not (ref/'Drive_shaft.step').is_file():
        source=os.environ.get('PILL_V7_STEP')
        if source:
            a=cq.Assembly.load(source)
            result=[]
            for name in REF_NAMES:
                item=a.objects['Dispensing_module_01/'+name].obj
                result.append(item if isinstance(item,cq.Shape) else item.val())
            return result
        raise FileNotFoundError('Supply the original V7 reference with --v7')
    return [cq.importers.importStep(str(ref/(name+'.step'))).val() for name in REF_NAMES]

def _core():
    # One-sided mount opens the entire other side of the coupling for its hex key.
    boss=cylinder(11.3,-33.15,-11)
    arms=[filleted_bar(0,0,x,y,4.9,-20.1,-11) for x,y in STATOR_PADS]
    # A straight-sided rib ties the motor face to the bearing tower.
    outline=[(-10,-20),(-9,-52),(-6.2,-58),(2.7,-58),(4.8,-55),(4.8,-30),(8.0,-20)]
    side=(cq.Workplane('YZ',origin=(8.1,0,0)).polyline(outline).close().extrude(4.6).val())
    profile=[(-7.2,-5.6),(7.0,-5.6),(10.,-8.),(13.,-8.),(13.,4.2),(10.5,5.6),(-7.2,5.6)]
    face=cq.Workplane('XY',origin=(0,0,-58.5)).polyline(profile).close().extrude(2.).val()
    # Broad pads carry the through-bolt bearing collars on the port plate.
    # The round pockets retain 1.5 mm of side wall before any local guide-side scallop.
    lands=[cylinder(6.3,-24.5,-11,x,y) for x,y in STATOR_PADS]
    body=boss.fuse(*arms,*lands,side,face)
    # The bearing stack bottoms on the rear annular shoulder.
    body=body.cut(cylinder(7.99,-31.87,-10.9),cylinder(6.25,-33.3,-31.85))
    for x in (-4.5,4.5):body=body.cut(cylinder(.95,-58.7,-56.4,x))
    body=body.cut(cylinder(2.75,-58.7,-56.4))
    return body.clean()

def guide_key(w,h,x0,x1):
    # Side plane faces +X. Its vertical obround provides repeatable chute clocking.
    return (cq.Workplane('YZ',origin=(x0,-5,46)).slot2D(h,w,90)
            .extrude(x1-x0).val())

def guide_insert():
    return ring(2.50,1.51,-6,0).rotate((0,0,0),(0,1,0),90).translate((23.25,-5.,46.))

def pedestal():
    # One rounded plate, with finger-size scallops at two exposed bolt heads and at the six-wire harness.
    foot_points=[(-18,-12),(18,-12),(23.,0),(37.5,26),(37.5,34.2),(32.5,38.4),
                 (-32.5,38.4),(-37.5,34.2),(-37.5,26),(-23.,0)]
    f=cq.Face.makeFromWires(cq.Workplane('XY').polyline(foot_points).close().val())
    foot=cq.Solid.extrudeLinear(f.fillet2D(3.,f.Vertices()).outerWire(),[],(0,0,5.))
    for x,y in MOUNT:foot=foot.cut(cylinder(1.70,-.2,5.2,x,y),cylinder(3.10,3.25,5.2,x,y))
    foot=foot.cut(cylinder(6.3,-.2,5.2,21,-13))
    # Tapered upright leaves the motor end and both set screws visible from the sides.
    sections=[(4.75,3.4,42.,26.,4.),(12.,3.0,39.4,24.3,4.),
              (56.,-.3,33.,17.7,3.4),(83.,-4.8,31.2,15.2,3.)]
    wires=[rounded_rectangle(w,d,0,y,z,r) for z,y,w,d,r in sections]
    post=cq.Solid.makeLoft(wires,True)
    front=tilt(cq.Solid.makeBox(170,170,95,(-85,-85,-16.3)))
    post=post.cut(front)
    # A permanent rising gusset takes the motor load down to the foot and supports
    # the motor-face plate as it prints. Its open side faces the removable guide.
    yz=[(-11.1,4.1),(-5.4,4.1),(-4.2,69.0),(-9.6,74.0),(-45.7,59.6),
        (-46.1,56.9),(-43.,52.1)]
    gusset=cq.Workplane('YZ',origin=(-12.4,0,0)).polyline(yz).close().extrude(4.0).val()
    stand=foot.fuse(post,gusset,tilt(_core()),guide_key(14.0,22.0,13.2,22.0),guide_key(8.0,14.0,21.95,23.25))
    guide_pilot=cq.Solid.makeCylinder(2.3,10.0,(23.28,-5,46),(-1,0,0)).fuse(
        cq.Solid.makeCone(2.67,2.30,.37,(23.25,-5,46),(-1,0,0)))
    stand=stand.cut(guide_pilot,cylinder(6.4,-.2,25.,21,-13))
    # Trim the aperture after fusing so no post can refill the bearing/shaft route.
    stand=stand.cut(tilt(cylinder(7.99,-31.87,-10.9)),tilt(cylinder(6.25,-33.3,-31.85)))
    for x,y in STATOR_PADS:
        stand=stand.cut(tilt(cylinder(4.80,-14.,-10.9,x,y)),tilt(insert_pilot(x,y,-14.)))
    # A through-access slot also keeps clear of the shaft and coupling beyond the rear shoulder.
    stand=stand.cut(tilt(cylinder(7.15,-55,-33.16)))
    # Match the flume exterior including its inclined end. The guide bearing/mating ear
    # is a separate upper feature and stays out of this clearance envelope.
    from guide26 import blank, WALL
    guide_mask=tilt(cq.Solid.makeBox(400,400,190.45,(-200,-200,-202.05)))
    flume_clearance=blank(WALL+.50).intersect(guide_mask)
    stand=stand.cut(flume_clearance).clean()
    assert stand.isValid() and len(stand.Solids())==1,(stand.isValid(),len(stand.Solids()))
    return stand

@lru_cache(1)
def parts():
    p=[('Pedestal_drive_saddle',pedestal(),'print'),
       ('Outer_race_spacing_sleeve',tilt(ring(7.73,6.32,-26.89,-16.13)),'print'),
       ('Front_R4_ZZ_bearing',tilt(bearing(-16.13)),'new'),
       ('Rear_R4_ZZ_bearing',tilt(bearing(-31.87)),'new')]
    for nm,shape in zip(REF_NAMES,hardware_shapes()):
        p.append((nm,tilt(shape.translate((0,0,9))),'reuse'))
    for i,(x,y) in enumerate(STATOR_PADS,1):
        p.append((f'Stator_M3x4_insert_{i}',tilt(insert(x,y,-14.)),'new'))
    p.append(('Guide_mount_M3x6_insert',guide_insert(),'new'))
    for i,(x,y) in enumerate(MOUNT,1):
        p.append((f'Deck_M3x8_SHCS_{i}',deck_screw(x,y),'new'))
    return p

