from pathlib import Path
import sys,math,json
import cadquery as cq
p=Path(sys.argv[1]);o=Path(sys.argv[2]);m=[]
bands=[('Pocket_metering_rotor',51.401,73.249,[-90+60*i for i in range(6)])]
if (p/'release/brep/Stationary_end_drop_guide.brep').exists():
    bands.append(('Stationary_end_drop_guide',74.501,84.999,[-150,-30,90]))
else:
    bands.append(('Vertical_queue_rotor',76.051,89.00,[-90+60*i for i in range(6)]))
for part,low,hi,angles in bands:
    shape=cq.Shape.importBrep(str(p/'release/brep'/(part+'.brep')))
    radii=[]
    for a in angles:
        x=15.6*math.cos(math.radians(a));y=15.6*math.sin(math.radians(a))
        axis=cq.Edge.makeLine((x,y,low),(x,y,hi))
        radius=axis.distance(shape);radii.append(round(radius,6))
    m.append(dict(part=part,AXIS_z_mm=[low,hi],axis_angles_deg=angles,axial_distance_to_solid_mm=radii,minimum_concentric_gauge_diameter_mm=2*min(radii),minimum_clearance_compared_to_7p75_mm=round(2*min(radii)-7.75,6)))
o.write_text(json.dumps(dict(method='Distance between each r15.6 mm pocket centerline segment and the actual solid BREP. Twice the smallest distance is a conservative concentric-cylinder diameter; tested over the given z window, including local reinforced socket intrusions. Straight upright clearance only.',rows=m),indent=2));print(m)
