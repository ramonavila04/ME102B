"""Track original loose bulk to an aligned queue, parked lower pocket and outlet across both revolutions."""
from pathlib import Path
import numpy as np, json, sys, math
first,second=map(Path,sys.argv[1:3])
report=json.loads((first/'motor/results.json').read_text());n=report['loaded']
state0=np.load(first/'fill/initial_pose.npz');q0=state0['qpos'][1:7*n+1].reshape(n,7);u0=np.abs(1-2*(q0[:,4]**2+q0[:,5]**2));zlow=q0[:,2]-3.875-7*u0
bulk=set(np.flatnonzero(zlow>115.6048).tolist());history={i:{}for i in sorted(bulk)}
lower_start=set();current=set()
for turn,d in enumerate([first,second]):
    s=json.loads((d/'motor/results.json').read_text())
    for c in s['steps']:
        k=c['step'];g=turn*6+k;state=np.load(d/'motor'/f'after_{k}.npz');q=state['qpos'][1:7*n+1].reshape(n,7);live=state['active'][:n];quad=q[:,3:];cos_tilt=np.abs(1-2*(quad[:,1]**2+quad[:,2]**2))
        a=state['qpos'][0]+np.deg2rad(-90+60*np.arange(6));cent=15.6*np.column_stack((np.cos(a),np.sin(a)))
        close=(np.min(np.linalg.norm(q[:,None,:2]-cent[None,:,:],axis=2),axis=1)<2.) & (cos_tilt>=np.cos(np.radians(15))) & live
        upper=close&(q[:,2]>75.60)&(q[:,2]<99.);lower=close&(q[:,2]<70)
        for j in sorted(bulk):
            if upper[j]:history[j].setdefault('first_aligned_upper_queue_at_park',g)
            if lower[j]:history[j].setdefault('first_aligned_lower_meter_at_park',g)
        for e in c['events']:
            if e['id'] in bulk and e['valid_outlet']:history[e['id']]['outlet_crossing_at_step']=g
        if g==6:lower_start=set(np.flatnonzero(lower).tolist())
        if turn==1:current=set(np.flatnonzero(lower).tolist())
out={'loaded':n,'park_commands_recorded':g,'highest_rotating_upper_surface_z_mm':115.6048,'initial_capsule_wholly_above_surface':len(bulk),'initial_bulk_IDs':sorted(bulk),'tracked_bulk_IDs':{i:{'original_center_z_mm':round(float(q0[i,2]),3),'original_bottom_tip_z_mm':round(float(zlow[i]),3),**v}for i,v in history.items()if v},'bulk_reached_upper_queue':sum('first_aligned_upper_queue_at_park' in v for v in history.values()),'bulk_reached_lower_meter':sum('first_aligned_lower_meter_at_park' in v for v in history.values()),'bulk_reached_outlet':sum('outlet_crossing_at_step' in v for v in history.values()),'second_turn_initial_occupied_lower_ids':sorted(lower_start),'latest_park_occupied_lower_ids':sorted(current),'criterion':'Original bulk has lowest tip above high point of bell mouth, z115.6048 mm. At the instant of each completed or interrupted command, aligned centers are within 2 mm of any actual rotating bore axis; axis tilt <=15 degrees. Upper queue centers 75.60<z<99 mm; lower pocket centers z<70 mm. Intermediate between-park transitions are not counted unless an outlet crossing is logged.'}
(second/'bulk_replenishment.json').write_text(json.dumps(out,indent=2))
print({k:v for k,v in out.items()if k not in ('tracked_bulk_IDs','initial_bulk_IDs','criterion')})
