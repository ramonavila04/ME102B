"""Evaluate geometry, tilt and contacts at saved poses without advancing simulated time."""
from pathlib import Path
import argparse,sys,math,json
import numpy as np
import mujoco as mj
p=argparse.ArgumentParser();p.add_argument('--code',type=Path,required=True);p.add_argument('--spec',type=Path,required=True);p.add_argument('--inertia',type=Path,required=True);p.add_argument('--second',type=Path,required=True);p.add_argument('--third',type=Path,required=True);a=p.parse_args();sys.path.insert(0,str(a.code));from closedfeed import cached,axis
from audit_helpers import label
read=lambda p:json.loads(p.read_text());spec=read(a.spec)
for inp in spec['parts'].values():inp[0]=str((a.spec.parent/inp[0]).resolve())
pack=read(a.third/'start/fill.json');mass=read(a.inertia);n=pack['loaded'];m=cached(spec,n,pack['body_od'],pack['friction'],.00025);rb=m.body('rotor').id;m.body_mass[rb]=mass['total_mass_g'];m.body_ipos[rb]=[0,0,mass['com_z_mm']];m.body_inertia[rb,:]=mass['total_kg_m2']*1e9
output={}
for step,path in [(8,a.second/'motor/after_2.npz'),(10,a.second/'motor/after_4.npz'),(11,a.second/'motor/after_5.npz'),(12,a.third/'start/initial_pose.npz'),(13,a.third/'motor/after_1.npz')]:
 d=mj.MjData(m);s=np.load(path);alive=s['active'][:n]
 for i in range(n):m.body_gravcomp[m.body(f'p{i}').id]=0. if alive[i] else 1.
 mj.mj_setConst(m,d);d.qpos[:]=s['qpos'][:m.nq];d.qvel[:]=s['qvel'][:m.nv];d.mocap_pos[0]=[0,0,0];mj.mj_forward(m,d);assert d.time==0
 q=d.qpos[1:7*n+1].reshape(n,7);v=axis(q[:,3:]);agg={};orient={}
 for k in np.flatnonzero(alive):
  k=int(k);xyz=q[k,:3]; shaft=v[k];agg[k]={};v0=shaft if shaft[2]>0 else -shaft
  orient[k]=dict(pos_mm=xyz.round(4).tolist(),unit_axis_up=v0.round(6).tolist(),tilt_deg=round(math.degrees(math.acos(np.clip(abs(shaft[2]),0,1))),3),bottom_tip_z=round(float(xyz[2]-3.875-7*abs(shaft[2])),4),speed_mm_s=round(float(np.linalg.norm(s['qvel'][1+6*k:1+6*k+3])),4))
 for i,c in enumerate(d.contact):
  labels=[label(m,c,j) for j in (0,1)];w=np.zeros(6);mj.mj_contactForce(m,d,i,w);F=np.array(c.frame).reshape(3,3).T@w[:3]*1e-6
  for j,lab in enumerate(labels):
   if not lab.startswith('pill'):continue
   k=int(lab[4:]);other=labels[1-j];row=agg[k].setdefault(other,{'force_on_capsule_N':np.zeros(3),'contact_xyz_mm':[]});row['force_on_capsule_N']+=(1 if j==1 else -1)*F;row['contact_xyz_mm'].append(c.pos.round(3).tolist())
 for k in agg:
  for row in agg[k].values():row['force_on_capsule_N']=row['force_on_capsule_N'].round(7).tolist()
 output[step]={'shaft_deg':float(np.degrees(d.qpos[0])),'poses':orient,'contacts':agg}
(a.third/'contact_diagnosis.json').write_text(json.dumps({'notes':'Exact checkpoint posing with restored inertia, all live flags and closed lid. mj_forward evaluated collision and constraint forces only, without integrating time. Forces are instantaneous estimates from the new forward solution; individual triangle-contact multiplicity does not imply distinct physical surfaces. Positive vertical force is upward. Modeled capsule weight is 0.004905 N.','frames':output},indent=1)+'\n')
for k in [2,7,17,32,50]:
 print('id',k,'new',output[12]['poses'][k], 'contacts',[(name,len(x['contact_xyz_mm']),round(x['force_on_capsule_N'][2],5))for name,x in output[12]['contacts'][k].items()]); print('track',[(s,output[s]['poses'][k]['pos_mm'][2],output[s]['poses'][k]['tilt_deg']) for s in output if k in output[s]['poses']]);
