"""Native B-rep before-motion checks for our three transfer lanes."""
from pathlib import Path
import math,sys,json
D=Path(__file__).parent;sys.path.insert(0,str(D))
from end_drop_feed import f, cq,distributor,rotor
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
s=distributor();lo=rotor()
def bound(s):
 b=Bnd_Box();b.SetGap(0.);BRepBndLib.AddOptimal_s(s.wrapped,b,False,False);return list(b.Get())
def zrange_at(x,y):
 r=f.cyl(.015,73.60,131,x,y).intersect(s);return [(round(v.BoundingBox().zmin,2),round(v.BoundingBox().zmax,2)) for v in r.Solids()]
def ga(x,y,z):return f.cyl(3.875,z,z+14,x,y).fuse(f.S.makeSphere(3.875,(x,y,z),angleDegrees1=-90),f.S.makeSphere(3.875,(x,y,z+14),angleDegrees1=-90)).clean()
checks=[];drive=f.cyl(5.75,73.45,90).fuse(f.cone(5.75,.5,90,95.25))
tools=__import__('end_drop_feed').end_drop_gallery()
for a in (-150,-30,90):
 x,y=f.phi(15.6,a);stages=[]
 for zlow in (51.05,55.,62.,70.,75.,81.,86.,92.,98.):
  pin=ga(x,y,zlow+3.875);common=sum(x.Volume()for x in pin.intersect(s).Solids());stages.append([zlow,round(common,7),round(s.distance(pin),4)])
 station=cq.Compound.makeCompound([f.rot(t,a)for t in tools]);e=BRepExtrema_DistShapeShape(drive.wrapped,station.wrapped);e.Perform();checks.append({'az':a,'upright_capsule_sweeps_'+ 'low_tip_z_and_intersect_mm3_and_min_clearance_mm':stages,'min_web_guide_void_to_rotor_blind_recess_mm':e.Value()})
# Left and right banks across tangent approach verify actual relief reaches the native solid.
r={'installed_guide_native_bbox_mm':bound(s),'native_crown_mm':bound(s)[-1],'guide_to_rotor_mm':lo.distance(s),'retaining_relief_to_throat':checks,'original_driver_stack':'Fixed candidate lower-wheel and capped drive hardware geometries identical','modelCrownTolerance_mm':.02,'bank_heights_native_xyz':{}}
for v in (-13,-10,-7,-4,-1,2,5):
 out=[]
 for u in (-5.,5.):
  x=15.6+u;y=v;a=math.radians(-150);x,y=x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a);out.append(zrange_at(x,y))
 r['bank_heights_native_xyz'][v]=out
(D/'passages.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
