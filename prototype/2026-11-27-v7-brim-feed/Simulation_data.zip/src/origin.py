"""Use capsule identity to distinguish prefilled cups, reloaded cups, and material from above the inlets."""
from pathlib import Path
import numpy as np
import json
from closedfeed import axis

def evaluate(fill, motor, inlet_top=None, fixed_galleries=None):
    pack=np.load(fill/'initial_pose.npz');r=json.loads((motor/'results.json').read_text())
    q=pack['qpos'][1:].reshape(-1,7);direction=axis(q[:,3:])
    bottom=q[:,2]-3.875-7*np.abs(direction[:,2]);tilt=np.degrees(np.arccos(np.clip(np.abs(direction[:,2]),0,1)))
    prestates={0:dict(q=q,live=pack['active'],angle=0)}
    for step in r['steps']:
        f=motor/f"after_{step['step']}.npz"
        if f.exists():
            st=np.load(f);prestates[step['step']]=dict(q=st['qpos'][1:].reshape(-1,7),live=st['active'],angle=step['end_deg'])
    def aligned_ids(st,in_upper=False):
        ids=np.flatnonzero(st['live']);points=st['q'][ids]
        centers=np.radians(fixed_galleries) if in_upper and fixed_galleries is not None else np.radians(-90+60*np.arange(6)+st['angle']);xy=15.6*np.column_stack((np.cos(centers),np.sin(centers)))
        nearby=np.min(np.linalg.norm(points[:,None,:2]-xy[None,:,:],axis=2),axis=1)<2.
        upright=np.abs(axis(points[:,3:])[:,2])>=np.cos(np.radians(15))
        band=(points[:,2]>=75.6)&(points[:,2]<99.0) if in_upper else points[:,2]<70
        return set(ids[band&nearby&upright].tolist())
    parked=aligned_ids(prestates[0]);upper_parked=aligned_ids(prestates[0],True)
    new_low={};new_upper={}
    for k,st in prestates.items():
        for i in aligned_ids(st,True):
            if i not in upper_parked and i not in new_upper:new_upper[i]=k
        for i in aligned_ids(st):
            if i not in parked and i not in new_low:new_low[i]=k
    drops=[]
    for s in r['steps']:
        for ev in s['events']:
            i=ev['id'];drops.append(dict(step=s['step'],completed=s['completed'],outlet=ev['valid_outlet'],id=i,initial_center_z_mm=round(float(q[i,2]),3),initial_low_tip_mm=round(float(bottom[i]),3),initial_tilt_degrees=round(float(tilt[i]),3),outlet_tilt_degrees=ev['tilt_degrees'],started_wholly_above_meter=bool(bottom[i]>73.25),initially_parked_in_lower_cup=i in parked,first_park_as_new_lower_occupant=new_low.get(i),started_wholly_above_highest_upper_inlet_surface=(bool(bottom[i]>inlet_top) if inlet_top is not None else None)))
    evidence=[]
    for i,k in sorted(new_low.items()):
        evidence.append(dict(id=i,first_seen_in_lower_cup_at_end_of_step=k,initial_z_mm=round(float(q[i,2]),3),initial_low_tip_z_mm=round(float(bottom[i]),3),lower_cup_center_z_mm=round(float(prestates[k]['q'][i,2]),3),started_wholly_above_highest_upper_inlet_surface=(bool(bottom[i]>inlet_top) if inlet_top is not None else None)))
    loose_into_guide=[]
    if inlet_top is not None:
        for i,k in sorted(new_upper.items()):
            if bottom[i]<=inlet_top:continue
            finalq=prestates[k]['q'][i]
            loose_into_guide.append(dict(id=i,index_first_parked_upright_in_guide=k,initial_low_tip_mm=round(float(bottom[i]),3),initial_center_z_mm=round(float(q[i,2]),3),initial_tilt_degrees=round(float(tilt[i]),3),first_upright_center_z_mm=round(float(finalq[2]),3),first_upright_tilt_degrees=round(float(np.degrees(np.arccos(np.clip(abs(axis(finalq[None,3:])[0,2]),0,1)))),3)))
    return dict(capsules=drops,originally_wholly_above_inlet_seen_in_upright_vertical_guide=loose_into_guide,initial_lower_cup_ids=sorted(parked),new_lower_cup_occupants=evidence,total_drops_started_wholly_above_lower_meter=sum(bool(d['started_wholly_above_meter'] and d['outlet']) for d in drops),total_drops_recorded_as_new_lower_cup_occupants=sum(d['outlet'] and d['first_park_as_new_lower_occupant'] is not None for d in drops),total_new_identified_lower_cup_occupants=len(evidence),mounted_inlet_highest_surface_z_mm=inlet_top,criterion='Parked lower cup occupancy uses z<70 mm, center within 2 mm of a moving cup axis at a park, and tilt no more than 15 degrees from vertical. The same alignment test from z75.6 to below 99.0 mm flags an upright capsule inside a feed guide. Crossing from the upper stack to a different lower pocket is distinguished from a fully bulk-origin capsule. Strict initial location above lower meter means its lowest tip exceeded z73.25 mm. For the most conservative bulk criterion its lowest tip must be above the highest surface of the six entrance/divider region (stationary canopy ignored). Capsule released between parks may have no lower occupancy checkpoint.')
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('fill',type=Path);p.add_argument('motor',type=Path);p.add_argument('output',type=Path);p.add_argument('--inlet-top',type=float);a=p.parse_args();a.output.write_text(json.dumps(evaluate(a.fill,a.motor,a.inlet_top),indent=2))
