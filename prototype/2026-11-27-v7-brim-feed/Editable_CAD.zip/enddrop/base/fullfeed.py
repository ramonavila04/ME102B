"""Two-stage vertical-queue cartridge. +Y faces outward, deck top z=0, millimeters."""
from pathlib import Path
from functools import lru_cache
import math,os,json,sys
from zipfile import ZipFile,ZIP_DEFLATED
import cadquery as cq
from cadquery import Solid as S,Vector as V
ROOT=Path(__file__).resolve().parent
REF=Path(os.environ.get('V7_FEED_REFERENCE',str(ROOT/'reference')))
REF_BREP=REF/'brep'
F=51.; R=15.6
MOUNT=[(0.,26.),(-26*math.sqrt(3)/2,-13.),(26*math.sqrt(3)/2,-13.)]
CUP_BASE=51.4; CUP_TOP=73.25; SEP_Z=73.65; SEP_TOP=75.60; QBASE=76.05
LEAD_ANGLE=float(os.environ.get('V7_QUEUE_LEAD','-157'))
RADIAL_INDEX=os.environ.get('V7_QUEUE_INDEX','radial')=='radial'
WELL_R=29.12; WALL_R=29.83; HOP_TOP=173.
def cyl(r,h1,h2,x=0,y=0):return S.makeCylinder(r,h2-h1,(x,y,h1))
def cone(r1,r2,h1,h2):return S.makeCone(r1,r2,h2-h1,(0,0,h1))
def rot(s,a):return s.rotate((0,0,0),(0,0,1),a)
def ring(ro,ri,a,b):return cyl(ro,a,b).cut(cyl(ri,a-.1,b+.1))
def box(x1,x2,y1,y2,z1,z2):return S.makeBox(x2-x1,y2-y1,z2-z1,(x1,y1,z1))
def phi(r,a):return (r*math.cos(math.radians(a)),r*math.sin(math.radians(a)))
def sector(ri,ro,a,b,z1,z2):
    return rot(S.makeCylinder(ro,z2-z1,(0,0,z1),(0,0,1),b-a).cut(cyl(ri,z1-.1,z2+.1)),a)
def poly(pts):return cq.Wire.makePolygon([V(*a) for a in pts]+[V(*pts[0])])
def ref(n):return cq.Shape.importBrep(str(REF_BREP/(n+'.brep')))
def dd(slack,z1,z2):
    shoulder=79.85
    blank=cyl(8.6+slack,z1,shoulder).fuse(cone(8.6+slack,4.35+slack,shoulder,z2))
    return blank.intersect(box(-7.65-slack,7.65+slack,-11,11,z1-.1,z2+.1))
@lru_cache(None)
def lower_drum():
    # Transfer only the physical old clamping-hub and bolt recess surfaces into the new cup carrier.
    base=cyl(21.55,CUP_BASE,CUP_TOP)
    for x in range(6):
        xx,yy=phi(R,-90+x*60)
        tool=cyl(4.72,CUP_BASE-.1,CUP_TOP+.1,xx,yy)
        top=S.makeCone(4.72,5.48,1.1,(xx,yy,CUP_TOP-1.07))
        base=base.cut(tool,top)
    socket=cyl(11.10,CUP_BASE,70.01).cut(ref('Six_flute_end_first_rotor'))
    base=base.cut(socket).fuse(dd(0,CUP_TOP-.05,84.1))
    return base.cut(cyl(1.76,69.8,84.2)).clean()

def wedge_top():
    # Smooth-sector profile, swept to a small regular lower circular passage via matched ruled sections.
    out=28.75;inn=5.0;ang=27.9
    seg=lambda a,b,n:[a+(b-a)*i/n for i in range(n)]
    pts=[phi(out,a) for a in seg(0,ang,6)]
    pts += [phi(r,ang) for r in seg(out,inn,9)]
    pts += [phi(inn,a) for a in seg(ang,-ang,12)]
    pts += [phi(r,-ang) for r in seg(inn,out,9)]
    pts += [phi(out,a) for a in seg(-ang,0,6)]
    c=R
    return [(x,y,math.atan2(y,x-c)) for x,y in pts]
def well():
    top=wedge_top()
    layers=[(QBASE-.2,0.),(98.2,0.),(105,.28),(113.5,.76),(118.8,1.),(139,1.)]
    wires=[]
    for z,w in layers:
        wires.append(poly([((1-w)*(R+4.7*math.cos(a))+w*tx,(1-w)*4.7*math.sin(a)+w*ty,z) for tx,ty,a in top]))
    return S.makeLoft(wires,True)
@lru_cache(None)
def queues():
    wall=cyl(WELL_R,QBASE,118.8).fuse(cone(WELL_R,4.30,118.8,129.1))
    tool=well()
    wall=wall.cut(*[rot(tool,-90+k*60) for k in range(6)])
    wall=wall.cut(dd(.26,QBASE-.1,84.35),cyl(1.76,84.15,86.53),cyl(3.26,86.50,131))
    return wall.clean()
def slope_tool():
    # The leading tip is 0.36 mm thick and rises to full thickness over roughly 8 mm of local travel.
    # Positive motion around the low-Y outlet increases theta. Project onto its local tangent.
    angle=LEAD_ANGLE;u=(-math.sin(math.radians(angle)),math.cos(math.radians(angle)));n=(u[1],-u[0]);origin=phi(R,angle)
    verts=[]
    for a,b in [(-60,-50),(60,-50),(60,50),(-60,50)]:
        verts.append((origin[0]+a*u[0]+b*n[0],origin[1]+a*u[1]+b*n[1],SEP_Z+.36+.20*a))
    return S.extrudeLinear(poly(verts),[],(0,0,120))
@lru_cache(None)
def rail():
    # A sector of floor for the rotating capsule queues; stays fixed during each index.
    s=sector(9.2,30.45,LEAD_ANGLE,-36,SEP_Z,SEP_TOP).cut(slope_tool())
    # Keep a continuous thin bevel face around the approach to avoid unsupported knife edges.
    return s.clean()
@lru_cache(None)
def keeper():
    ring_blank=ring(31.65,WALL_R,SEP_Z,SEP_TOP)
    # The production shelf has a single outer-edge notch that locates on the stationary collar lug.
    if RADIAL_INDEX:
        slot=rot(box(30.40,32.0,-2.30,2.30,SEP_Z-.1,SEP_TOP+.1),85)
        return rail().fuse(ring_blank.cut(slot)).clean()
    index_tab=rot(box(30.45,31.6,-2.0,2.0,SEP_Z-2.25,SEP_Z+.15),85)
    return rail().fuse(ring_blank,index_tab).clean()
@lru_cache(None)
def basewall():
    collar=ring(31.65,WALL_R,F,SEP_Z)
    for x,y in MOUNT:
        a=math.degrees(math.atan2(y,x))
        collar=collar.fuse(cyl(3.45,F,F+3,x,y),rot(box(25.9,30.4,-3.3,3.3,F,F+3),a)).cut(cyl(1.72,F-.1,F+3.1,x,y))
    # Bayonet: a reinforced outer collar traps the feed shelf when the hopper is locked.
    key=rot(box(30.18,31.9,-2.35,2.35,SEP_Z-2.5,SEP_Z+.2),85)
    if not RADIAL_INDEX:collar=collar.cut(key)
    band=ring(33.55,31.93,SEP_Z-4.10,SEP_TOP+7.1)
    # Retaining ledge and entry relief for two 12-degree bayonet lugs.
    outer_base=cone(31.65,33.55,SEP_Z-7,SEP_Z-4.9).fuse(cyl(33.55,SEP_Z-4.9,SEP_Z-4.0))
    collar=collar.fuse(outer_base.cut(cyl(31.4,SEP_Z-7.1,SEP_Z-3.9)),band)
    for angle in (28,208):
        collar=collar.cut(sector(31.45,34,angle-5.5,angle+17.3,SEP_TOP+1.25,SEP_TOP+4.7),
                          sector(31.45,34,angle+7.3,angle+17.3,SEP_TOP+1.25,SEP_TOP+7.3))
    if RADIAL_INDEX:
        lug=rot(box(30.68,32.11,-1.95,1.95,SEP_Z-.14,SEP_TOP-.10),85)
        collar=collar.fuse(lug)
    return collar.clean()
def ledge(angle,z,r_in,r_out):
    return rot(box(r_in,r_out,-1.5,1.5,z,z+2.9),angle)
@lru_cache(None)
def reservoir():
    body=ring(31.65,WALL_R,SEP_TOP,HOP_TOP)
    # Two stud ends are ramped for an upright print. The body seats on the fixed shelf.
    for angle in (28,208):
        pp=poly([(31.40,-1.95,SEP_TOP+1.62),(31.40,-1.95,SEP_TOP+4.28),
            (33.16,-1.95,SEP_TOP+4.28),(33.16,-1.95,SEP_TOP+3.15)])
        body=body.fuse(rot(S.extrudeLinear(pp,[],(0,3.9,0)),angle))
    # Break small co-rotating clusters with open, sloped wall ribs; bottom clears all revolution angles.
    for ang in (35,155,275):
        t=poly([(20.2,-1.1,135.5),(29.95,-1.1,121.8),(29.95,-1.1,142.0)])
        ramp=rot(S.extrudeLinear(t,[],(0,2.2,0)),ang)
        body=body.fuse(ramp)
    return body.clean()
@lru_cache(None)
def lid():
    return cyl(32.1,HOP_TOP,HOP_TOP+2.).fuse(ring(29.55,27.7,HOP_TOP-3.5,HOP_TOP+.1)).clean()
def emit_test():
    p=Path(os.environ.get('V7_QUEUE_CONTACT',str(ROOT/'contact_radial')));p.mkdir(exist_ok=True,parents=True)
    objs={'floor':ref('Ported_floor_and_bearing_carrier'),'collar':basewall(),'roof':keeper(),'magazine':reservoir(),'rotor':cq.Compound.makeCompound([lower_drum(),queues()])}
    for n,s in objs.items():
        print(n,len(s.Solids()),s.isValid(),flush=True);s.exportStl(str(p/(n+'.stl')),tolerance=.10,angularTolerance=.22)
if __name__=='__main__':emit_test()
