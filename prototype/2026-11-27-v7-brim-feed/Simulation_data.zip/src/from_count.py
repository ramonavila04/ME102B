"""Seed a loose pour with a specified count, then top off and run six torque-limited commands."""
from pathlib import Path
import argparse
from study import run
from brim import topoff
from campaign import history

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('spec',type=Path);p.add_argument('inertia',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--seed',type=int,required=True);p.add_argument('--mu',type=float,required=True)
    p.add_argument('--count',type=int,required=True);p.add_argument('--attempts',type=int,default=54)
    a=p.parse_args();s=a.spec.resolve();base=a.out/'topoff_source';ready=a.out/'fill'
    run(s,base,seed=a.seed,mu=a.mu,dt=.001,state=str(a.count),cycles=0)
    topoff(s,base,ready,dt=.001,max_attempts=a.attempts)
    history(s,ready,a.inertia,a.out/'motor',dt=.0005,cycles=6)
