"""Rigid concave mesh contact study; lengths in mm, mass in g, time in seconds."""
from pathlib import Path
import xml.etree.ElementTree as E
import sys,time,math,json,hashlib,csv,argparse
import numpy as np
import mujoco as mj
HERE=Path(__file__).resolve().parent
def v(a):return ' '.join(f'{n:.6g}' for n in np.ravel(a))
def inds(a):return ' '.join(str(n) for n in np.ravel(a))
def mesh(file):
 b=file.read_bytes();a=np.frombuffer(b,offset=84,dtype=[('n','<f4',(3,)),('v','<f4',(3,3)),('tag','<u2')])
 t=a['v'].astype('float64')
 ok=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)>.00005
 t=t[ok];vv,ii=np.unique(t.reshape(-1,3).round(5),axis=0,return_inverse=True)
 return vv,ii.reshape(-1,3)
def model(spec,n,od,mu,dt):
 root=E.Element('mujoco'); E.SubElement(root,'compiler',angle='radian',inertiafromgeom='false')
 opt=E.SubElement(root,'option',timestep=str(dt),gravity='0 0 -9810',solver='Newton',iterations='20',cone='pyramidal',jacobian='sparse',integrator='implicitfast')
 E.SubElement(root,'size',memory='96M')
 df=E.SubElement(root,'default')
 params=dict(condim='3',friction=f'{mu} .01 .005',solref='.004 1.2',solimp='.98 .995 .08')
 E.SubElement(df,'geom',**params)
 w=E.SubElement(root,'worldbody')
 rb=E.SubElement(w,'body',name='rotor')
 E.SubElement(rb,'joint',name='axle',type='hinge',axis='0 0 1')
 E.SubElement(rb,'inertial',pos='0 0 65',mass='10000',diaginertia='2000000 2000000 2000000')
 de=E.SubElement(root,'deformable')
 for name,(f,domain) in spec['parts'].items():
  vv,ii=mesh(Path(f))
  flex=E.SubElement(de,'flex',name=name,dim='2',body=domain,radius='.045',vertex=v(vv),element=inds(ii))
  E.SubElement(flex,'contact',contype='1',conaffinity='2',selfcollide='none',internal='false',**params)
 # When shut the underside of the cap spans the whole bore (cap simplified as planar stop, disabled during pouring).
 cap=E.SubElement(w,'geom',type='box',name='lid',size='33 33 1',pos=f"0 0 {spec['lid']+1}",contype='0',conaffinity='0')
 for i in range(n):
  p=E.SubElement(w,'body',name=f'p{i}',pos=f'{500+30*i} 0 110',gravcomp='1')
  E.SubElement(p,'freejoint',name=f'f{i}')
  E.SubElement(p,'inertial',pos='0 0 0',mass='.50',diaginertia='18 18 3.55')
  E.SubElement(p,'geom',type='capsule',name=f'pill{i}',size=v([od/2,(21.75-od)/2]),contype='2',conaffinity='3')
  E.SubElement(p,'geom',type='sphere',name=f'seam{i}',size='.1',pos='0 0 0',contype='0',conaffinity='0')
 return mj.MjModel.from_xml_string(E.tostring(root,encoding='unicode'))
def axis(q):
 w,x,y,z=q.T;return np.column_stack((2*(x*z+w*y),2*(y*z-w*x),1-2*(x*x+y*y)))
def cached(spec,n,od,mu,dt):
 raw=json.dumps(spec,sort_keys=True)+str((n,od,mu,dt,mj.__version__))+hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 keys=[hashlib.sha256(Path(f).read_bytes()).hexdigest() for f,_ in spec['parts'].values()]
 key=hashlib.sha256((raw+','.join(keys)).encode()).hexdigest()[:16]
 folder=HERE/'cache';folder.mkdir(exist_ok=True);p=folder/(key+'.mjb')
 if p.exists():return mj.MjModel.from_binary_path(str(p))
 import os
 m=model(spec,n,od,mu,dt);tmp=p.with_suffix(f'.{os.getpid()}.mjb');mj.mj_saveModel(m,str(tmp));tmp.replace(p);return m
