"""Isolated shaft check for the sampled velocity/drag feedback near a parked fixed distributor."""
from pathlib import Path
import json,math,argparse
def empty_shaft(inertia,dt):
    w=theta=accum=ref=0.;stop_count=0.;good=None;rows=[]
    for i in range(round(8/dt)):
        err=math.pi/3-theta
        desired=min(math.pi/10,max(-math.pi/10,6*err));ref+=min(5*dt,max(-5*dt,desired-ref))
        ve=ref-w;new=accum+.4*ve*dt;p=.015*ve
        if abs(p+new)<=.1 or (p+new)*ve<0:accum=new
        tau=min(.1,max(-.1,p+accum));drag=.002*math.tanh(w/.08)+.0005*w
        w+=dt*(tau-drag)/inertia;theta+=dt*w
        within=(abs(math.degrees(theta)-60)<=.30 and abs(math.degrees(w))<=1)
        stop_count=stop_count+dt if within else 0.
        if good is None and stop_count>=.15:good=(i+1)*dt
        if (i+1)*dt>=7:rows.append((math.degrees(theta),math.degrees(w)))
    return dict(dt_s=dt,local_linear_velocity_multiplier=1-dt*(.015+.002/.08+.0005)/inertia,qualified_settle_time_s=good,final_second_min_max_angle_deg=[min(r[0] for r in rows),max(r[0] for r in rows)],final_second_min_max_velocity_deg_s=[min(r[1] for r in rows),max(r[1] for r in rows)])
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('inertia',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
    I=json.loads(a.inertia.read_text())['total_kg_m2']
    result=dict(context='Isolated one-degree-of-freedom rotor with the same explicit controller and drag model; no capsules or geometries, no contacts. Supplementary numerical diagnosis only.',inertia_kg_m2=I,peak_motor_Nm=.10,measures=[empty_shaft(I,dt) for dt in [.0005,.00025,.000125]])
    a.out.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
