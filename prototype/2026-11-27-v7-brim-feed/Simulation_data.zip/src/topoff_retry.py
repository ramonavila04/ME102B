"""Continue a closable preliminary pack with more physical single gravity insertions, preserving every existing capsule."""
import argparse,sys,subprocess,json
from pathlib import Path
from brim import topoff
from campaign import read,write,sha

p=argparse.ArgumentParser()
for k in ('spec','inertia','out'):p.add_argument(k,type=Path)
p.add_argument('--crown',type=float,required=True);p.add_argument('--attempts',type=int,default=50)
a=p.parse_args();s=a.spec.resolve();out=a.out.resolve();initial=out/'fill';old=out/'brim_pass1'
assert not (out/'motor/results.json').exists() and not old.exists()
why=out/'unsuitable_packing.json';assert why.exists() and (initial/'initial_pose.npz').exists()
initial.rename(old);why.rename(old/'unsuitable_packing.json')
topoff(s,old,initial,dt=.001,max_attempts=a.attempts,reject_limit=25,seed_offset=2000)
prev=read(old/'fill.json');nxt=read(initial/'fill.json')
row=dict(first_pass_loaded=prev['loaded'],first_pass_top_freeboard_mm=prev['lid_freeboard_mm'],
    first_pass_median_top_freeboard_mm=prev['median_sector_freeboard_mm'],first_pass_state=sha(old/'initial_pose.npz'),
    second_pass_seed_offset=2000,second_pass_max_attempts=a.attempts,final_pose_sha256=sha(initial/'initial_pose.npz'),
    new_loaded=nxt['loaded'],new_tip_freeboard_mm=nxt['lid_freeboard_mm'],new_median_top_freeboard_mm=nxt['median_sector_freeboard_mm'],
    note='Existing settled positions, orientations, velocities and identities are carried forward. Further singly dropped capsules alone change density. As for the first topoff stage, contact warm-start resets at this preparatory boundary. No dosing motion before closure qualification.')
write(out/'topoff_restart.json',row)
cmd=[sys.executable,str(Path(__file__).resolve().parent/'active_campaign.py'),str(s),str(a.inertia.resolve()),str(out),'--from-fill',str(initial),'--crown',str(a.crown)]
raise SystemExit(subprocess.call(cmd))
